﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace r_121_Y___23_X____s_tim_da_je_x_3_y
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nadji_nepoznat_broj(int baza, int broj)
            {
                string rjesenje_broj = "";
                int racun = 0;
                string znamenke = "0123456789ABCDEF";

                while (broj > 0)
                {
                    racun = broj % baza;
                    rjesenje_broj = znamenke[racun] + rjesenje_broj;
                    broj /= baza;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }

            Random rnd = new Random();

            Console.Write("Koliko zadataka trebate? ");
            int broj_zadataka = Convert.ToInt32(Console.ReadLine());

            int GlavniBroj;

            int baza1, baza2;

            string brojString = "";

            int odnos;
            int odnosPredznak;

            string zapisiZad = "", zapisiRije = "";
            string fileZad = "zadatci.txt", fileRije = "rijesenja.txt";

            int brojIzvrsenih = 0;

            while (brojIzvrsenih < broj_zadataka)
            {
                pocetak:

                GlavniBroj = rnd.Next(10, 999);
                baza1 = rnd.Next(2, 13);
                odnos = rnd.Next(1, 5);
                odnosPredznak = rnd.Next(1, 3);

                if (odnosPredznak == 1 && baza1 - odnos > 1)
                {
                    baza2 = baza1 - odnos;
                    
                    //gleda je li prva znamenka prikladna za bazu, radi lakseg racunanja 
                    brojString = nadji_nepoznat_broj(baza1, GlavniBroj).ToString();
                    int firstDigitValue = "0123456789ABCDEF".IndexOf(brojString[0]);
                    if (firstDigitValue != baza1 - 1) { goto pocetak; }
                    
                    brojIzvrsenih++;

                    zapisiZad = zapisiZad + $"{nadji_nepoznat_broj(baza1, GlavniBroj)} (X) = {nadji_nepoznat_broj(baza2, GlavniBroj)} (Y), Y = X - {odnos}\n";
                    zapisiRije = zapisiRije + $"Y = {baza2}, X = {baza1}\n";
                }
                else if (odnosPredznak == 2 && baza1 + odnos < 17)
                {
                    baza2 = baza1 + odnos;

                    //gleda je li prva znamenka prikladna za bazu, radi lakseg racunanja 
                    brojString = nadji_nepoznat_broj(baza1, GlavniBroj).ToString();
                    int firstDigitValue = "0123456789ABCDEF".IndexOf(brojString[0]);
                    if (firstDigitValue != baza1 - 1) { goto pocetak; }

                    brojIzvrsenih++;
                    
                    zapisiZad = zapisiZad + $"{nadji_nepoznat_broj(baza1, GlavniBroj)} (X) = {nadji_nepoznat_broj(baza2, GlavniBroj)} (Y), Y = X + {odnos}\n";
                    zapisiRije = zapisiRije + $"Y = {baza2}, X = {baza1}\n";
                }
                else { goto pocetak; }
            }

            File.WriteAllText(fileRije, zapisiRije);
            File.WriteAllText(fileZad, zapisiZad);
        }
    }
}
