﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Direktna_transformacija_baza
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            string nadji_nepoznat_broj(int baza, int broj)
            {
                string rjesenje_broj = "";
                int racun = 0;
                string znamenke = "0123456789ABCDEF";

                while (broj > 0)
                {
                    racun = broj % baza;
                    rjesenje_broj = znamenke[racun] + rjesenje_broj;
                    broj /= baza;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }
            int odrediBazu(int baza)
            {
                Random random = new Random();

                int rendomBroj = random.Next(0, 5);

                if (rendomBroj == 0) baza = 2;
                if (rendomBroj == 1) baza = 4;
                if (rendomBroj == 2) baza = 8;
                if (rendomBroj == 3) baza = 10;
                if (rendomBroj == 4) baza = 16;

                return baza;
            }

            int baza1 = 0, baza2 = 0;

            Console.Write("Koliko zadataka želite? ");
            int brojZadataka = Convert.ToInt32(Console.ReadLine());

            int dekBroj;

            string fileZad = "zadatci.txt", fileRj = "rijecenja.txt";
            string zapisiZad = "", zapisiRj = "";

            for (int i = 0; i < brojZadataka;)
            {
                dekBroj = rnd.Next(10, 1000);

                baza1 = odrediBazu(baza1);
                baza2 = odrediBazu(baza2);

                if (baza1 != baza2)
                {
                    zapisiZad += $"{nadji_nepoznat_broj(baza1, dekBroj)} ({baza1}) = X ({baza2})\n";
                    zapisiRj += $"X = {nadji_nepoznat_broj(baza2, dekBroj)}\n";
                    i++;
                }
            }

            File.WriteAllText(fileZad, zapisiZad);
            File.WriteAllText(fileRj, zapisiRj);
        }
    }
}
