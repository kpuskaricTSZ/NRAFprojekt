﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace Rijesavanje_sustava_linearnih_jednadzbi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            string nadji_nepoznat_broj(int baza, int broj)
            {
                string rjesenje_broj = "";
                int racun = 0;
                string znamenke = "0123456789ABCDEF";

                while (broj > 0)
                {
                    racun = broj % baza;
                    rjesenje_broj = znamenke[racun] + rjesenje_broj;
                    broj /= baza;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }

            int odredjivanjeBaze(Random slucajni)
            {
                int bazaOdredjivanja = 0;

                int random = slucajni.Next(1, 6);

                if (random == 1) bazaOdredjivanja = 2;
                if (random == 2) bazaOdredjivanja = 4;
                if (random == 3) bazaOdredjivanja = 8;
                if (random == 4) bazaOdredjivanja = 10;
                if (random == 5) bazaOdredjivanja = 16;

                return bazaOdredjivanja;
            }

            int prviBroj, drugiBroj, treciBroj, cetvrtiBroj, petiBroj, sestiBroj;

            int bazaPrviBroj, bazaDrugiBroj, bazaTreciBroj, bazaCetvrtiBroj, bazaPetiBroj, bazaSestiBroj;
            int prvaBazaRijesenja, drugaBazaRijesenja;

            int prviBrojRijesenja, drugiBrojRijesenja;

            string fileZad = "zadatci.txt", fileRj = "rjesenja.txt";
            string zapisiZad = "", zapisiRj = "";

            Console.Write("Koliko zadataka tražite? ");
            int brojZadataka = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < brojZadataka; i++)
            {
                //odredjivanje brojeva
                prviBroj = rnd.Next(1, 33);
                drugiBroj = rnd.Next(1, 33);
                treciBroj = rnd.Next(1, 33);
                cetvrtiBroj = rnd.Next(1, 33);
                petiBroj = rnd.Next(1, 33);
                sestiBroj = rnd.Next(1, 33);

                //odredjivanje brojeva rijesenja
                //drugiBroj i cetvrtiBroj su nepoznanice
                prviBrojRijesenja = prviBroj * drugiBroj + treciBroj * cetvrtiBroj;
                drugiBrojRijesenja = petiBroj * drugiBroj + sestiBroj * cetvrtiBroj;

                //odredjivanje baza
                bazaPrviBroj = odredjivanjeBaze(rnd);
                bazaDrugiBroj = odredjivanjeBaze(rnd);
                bazaTreciBroj = odredjivanjeBaze(rnd);
                bazaCetvrtiBroj = odredjivanjeBaze(rnd);
                bazaPetiBroj = odredjivanjeBaze(rnd);
                bazaSestiBroj = odredjivanjeBaze(rnd);

                prvaBazaRijesenja = odredjivanjeBaze(rnd);
                drugaBazaRijesenja = odredjivanjeBaze(rnd);

                //zapisivanje u zadatke i rijesenja
                zapisiZad = zapisiZad + $"{nadji_nepoznat_broj(bazaPrviBroj, prviBroj)}({bazaPrviBroj}) * X({bazaDrugiBroj}) + " +
                $"{nadji_nepoznat_broj(bazaTreciBroj, treciBroj)}({bazaTreciBroj}) * Y({bazaCetvrtiBroj})" +
                $" = {nadji_nepoznat_broj(prvaBazaRijesenja, prviBrojRijesenja)}({prvaBazaRijesenja})\n";
                zapisiZad = zapisiZad + $"{nadji_nepoznat_broj(bazaPetiBroj, petiBroj)}({bazaPetiBroj}) * X({bazaDrugiBroj}) + " +
                $"{nadji_nepoznat_broj(bazaSestiBroj, sestiBroj)}({bazaSestiBroj}) * Y({bazaCetvrtiBroj})" +
                $" = {nadji_nepoznat_broj(drugaBazaRijesenja, drugiBrojRijesenja)}({drugaBazaRijesenja})\n\n";

                zapisiRj = zapisiRj + $"X = {nadji_nepoznat_broj(bazaDrugiBroj, drugiBroj)}({bazaDrugiBroj})," +
                $" Y = {nadji_nepoznat_broj(bazaCetvrtiBroj, cetvrtiBroj)}({bazaCetvrtiBroj})\n";
            }

            File.WriteAllText(fileZad, zapisiZad);
            File.WriteAllText(fileRj, zapisiRj);
        }
    }
}
