﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Odredivanje_drugog_komplementa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            string nadji_nepoznat_broj(int baza, int broj)
            {
                string rjesenje_broj = "";
                int racun = 0;
                string znamenke = "0123456789ABCDEF";

                while (broj > 0)
                {
                    racun = broj % baza;
                    rjesenje_broj = znamenke[racun] + rjesenje_broj;
                    broj /= baza;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }

            string drugiKomplement(string brojuBinarnom)
            {
                string rjesenje = "";

                int numberOfBits = 8;
                string brojZbrajanje = "1";

                while (brojuBinarnom.Length <= numberOfBits)
                {
                    brojuBinarnom = "0" + brojuBinarnom;
                }
                while (brojZbrajanje.Length <= numberOfBits)
                {
                    brojZbrajanje = "0" + brojZbrajanje;
                }

                for (int i = 0; i < brojuBinarnom.Length; i++)
                {
                    if (brojuBinarnom[i] == Convert.ToChar("0")) rjesenje = rjesenje + "1";
                    if (brojuBinarnom[i] == Convert.ToChar("1")) rjesenje = rjesenje + "0";
                }

                string rezultat = "";
                int prebacivanje = 0;

                int brojJedinicaURedku = 0;

                for (int i = rjesenje.Length - 1; i > 0; i--)
                {
                    if (prebacivanje == 1) brojJedinicaURedku++;
                    if (rjesenje[i] == Convert.ToChar("1")) brojJedinicaURedku++;
                    if (brojZbrajanje[i] == Convert.ToChar("1")) brojJedinicaURedku++;

                    if (brojJedinicaURedku == 0) { rezultat = "0" + rezultat; prebacivanje = 0; }
                    if (brojJedinicaURedku == 1) { prebacivanje = 0; rezultat = "1" + rezultat; }
                    if (brojJedinicaURedku == 2) { prebacivanje = 1; rezultat = "0" + rezultat; }
                    if (brojJedinicaURedku == 3) { prebacivanje = 1; rezultat = "1" + rezultat; }
                    brojJedinicaURedku = 0;
                }

                return rezultat;
            }

            int bazaGlavna = 2;
            int brojPrviGlavni, brojDrugiGlavni, razlikaBrojeva = 0;
            string prviBinarniBrojGlavno, drugiBinarniBroj, drugiBinarniBrojGlavno, razlikaBrojevaBinarno, razlikaBrojevaBinarnoGlavno;

            string fileZad = "zadatci.txt", fileRj = "rjesenja.txt";
            string zapisiZad = "", zapisiRj = "";

            Console.Write("Koliko zadataka tražite? ");
            int brojZadataka = Convert.ToInt32(Console.ReadLine());

            int brojBitova = 8;
            int brojManjiOdNule = 0;

            for (int i = 0; i < brojZadataka; i++)
            {
                pocetakLoopa:

                brojPrviGlavni = rnd.Next(16, 129);
                brojDrugiGlavni = rnd.Next(16, 129);

                razlikaBrojeva = brojDrugiGlavni - brojPrviGlavni;
                if (brojPrviGlavni == brojDrugiGlavni) goto pocetakLoopa;
                if (razlikaBrojeva < 0)
                {
                    while (brojManjiOdNule + razlikaBrojeva != 0) brojManjiOdNule++;

                    razlikaBrojevaBinarno = nadji_nepoznat_broj(bazaGlavna, brojManjiOdNule);
                    razlikaBrojevaBinarnoGlavno = drugiKomplement(razlikaBrojevaBinarno);
                }
                else
                {
                    razlikaBrojevaBinarnoGlavno = nadji_nepoznat_broj(bazaGlavna, razlikaBrojeva);
                    while (razlikaBrojevaBinarnoGlavno.Length <= brojBitova) razlikaBrojevaBinarnoGlavno = "0" + razlikaBrojevaBinarnoGlavno;
                }

                prviBinarniBrojGlavno = nadji_nepoznat_broj(bazaGlavna, brojPrviGlavni);
                while (prviBinarniBrojGlavno.Length <= brojBitova) prviBinarniBrojGlavno = "0" + prviBinarniBrojGlavno;
                
                drugiBinarniBroj = nadji_nepoznat_broj(bazaGlavna, brojDrugiGlavni);
                drugiBinarniBrojGlavno = drugiKomplement(drugiBinarniBroj);
                
                zapisiZad = zapisiZad + $"{prviBinarniBrojGlavno} + {drugiBinarniBrojGlavno} = \n";
                zapisiRj = zapisiRj + $"{razlikaBrojevaBinarnoGlavno} (2)\t\t\t{razlikaBrojeva} (10)\n";

                brojManjiOdNule = 0;
            }

            File.WriteAllText(fileZad, zapisiZad);
            File.WriteAllText(fileRj, zapisiRj);
        }
    }
}
