﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace iz_nekog_brojevnog_u_dek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random slucajniBroj = new Random();
            string nadji_nepoznat_broj(int baza, int dekBroj)
            {
                string rjesenje_broj = "";

                while (dekBroj > 0)
                {
                    rjesenje_broj = (dekBroj % baza).ToString() + rjesenje_broj;
                    dekBroj /= baza;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }

            string fileZad = "zadatci.txt", fileRije = "rijesenja.txt";

            string zapisiZad = "", zapisiRije = "";

            Console.Write("Koliko zadataka želite? ");
            int brojZad = Convert.ToInt32(Console.ReadLine()),
                bazaZad = 0,
                rijesenje = 0;

            for (int i = 0; i < brojZad; i++)
            {
                bazaZad = slucajniBroj.Next(2, 10);
                rijesenje = slucajniBroj.Next(100, 1000);

                zapisiZad += $"{nadji_nepoznat_broj(bazaZad, rijesenje)} ({bazaZad}) = X (10)\n";
                zapisiRije += $"X (10) = {rijesenje}\n";
            }

            File.WriteAllText(fileZad, zapisiZad);
            File.WriteAllText(fileRije, zapisiRije);
        }
    }
}
