﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace iz_dek_brojevnog_sustava_u_neki_brojevni_sustav
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random slucajniBroj = new Random();
            string nadji_nepoznat_broj(int baza, int dekBroj)
            {
                string rjesenje_broj = "";

                while (dekBroj > 0)
                {
                    rjesenje_broj = (dekBroj % baza).ToString() + rjesenje_broj;
                    dekBroj /= baza;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }

            Console.Write("Koliko zadataka želite? ");
            int broj_zadataka = Convert.ToInt32(Console.ReadLine());

            string zadatcifile = "zadatci.txt";
            string rijesenjafile = "rijesenja.txt";

            string zapisiZad = "";
            string zapisiRije = "";

            int bazaTrazena;
            int broj;

            for (int i = 0; i < broj_zadataka; i++)
            {
                bazaTrazena = slucajniBroj.Next(2, 10);
                broj = slucajniBroj.Next(100, 1000);

                zapisiZad += $"{broj} (10) = X ({bazaTrazena})\n";
                zapisiRije += $"X ({bazaTrazena}) = {nadji_nepoznat_broj(bazaTrazena, broj)}\n";
            }

            File.WriteAllText(zadatcifile, zapisiZad);
            File.WriteAllText(rijesenjafile, zapisiRije);
            Console.ReadKey();
        }
    }
}
