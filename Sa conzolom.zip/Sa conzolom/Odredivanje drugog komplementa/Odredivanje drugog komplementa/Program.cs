﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Odredivanje_drugog_komplementa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            string nadji_nepoznat_broj(int baza, int broj)
            {
                string rjesenje_broj = "";
                int racun = 0;
                string znamenke = "0123456789ABCDEF";

                while (broj > 0)
                {
                    racun = broj % baza;
                    rjesenje_broj = znamenke[racun] + rjesenje_broj;
                    broj /= baza;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }

            string prviKomplement (string brojuBinarnom)
            {
                string rjesenje = "";

                for (int i = 0; i < brojuBinarnom.Length; i++)
                {
                    if (brojuBinarnom[i] == Convert.ToChar("0")) rjesenje = rjesenje + "1";
                    if (brojuBinarnom[i] == Convert.ToChar("1")) rjesenje = rjesenje + "0";
                }

                return rjesenje;
            }

            string zbrajanjeBinarnihBrojeva (string prviBinarniBroj, string drugiBinarniBroj)
            {
                string rezultat = "";
                int prebacivanje = 0;

                int brojJedinicaURedku = 0;

                for (int i = prviBinarniBroj.Length-1;  i > 0; i--)
                {
                    if (prebacivanje == 1) brojJedinicaURedku++;
                    if (prviBinarniBroj[i] == Convert.ToChar("1")) brojJedinicaURedku++;
                    if (drugiBinarniBroj[i] == Convert.ToChar("1")) brojJedinicaURedku++;

                    if (brojJedinicaURedku == 0) { rezultat = "0" + rezultat; prebacivanje = 0; }
                    if (brojJedinicaURedku == 1) { prebacivanje = 0; rezultat = "1" + rezultat; }
                    if (brojJedinicaURedku == 2) { prebacivanje = 1; rezultat = "0" + rezultat; }
                    if (brojJedinicaURedku == 3) { prebacivanje = 1; rezultat = "1" + rezultat; }
                    brojJedinicaURedku = 0;
                }

                return rezultat;
            }

            int bazaGlavna = 2;
            int brojGlavni;
            string brojBinarno, brojKomplementni, resenje;

            string fileZad = "zadatci.txt", fileRj = "rjesenja.txt";
            string zapisiZad = "", zapisiRj = "";

            Console.Write("Koliko zadataka tražite? ");
            int brojZadataka = Convert.ToInt32(Console.ReadLine());

            int numberOfBits = 8;
            string brojZbrajanje = "1";

            for (int i = 0; i < brojZadataka; i++)
            {
                brojGlavni = rnd.Next(16, 129);

                brojBinarno = nadji_nepoznat_broj(bazaGlavna, brojGlavni);

                while (brojBinarno.Length <= numberOfBits)
                {
                    brojBinarno = "0" + brojBinarno;
                }
                while (brojZbrajanje.Length <= numberOfBits)
                {
                    brojZbrajanje = "0" + brojZbrajanje;
                }

                brojKomplementni = prviKomplement(brojBinarno);
                resenje = zbrajanjeBinarnihBrojeva(brojKomplementni, brojZbrajanje);

                zapisiZad = zapisiZad + $"-{brojGlavni} =\n";
                zapisiRj = zapisiRj + $"{resenje}\n";
            }
            
            File.WriteAllText(fileZad, zapisiZad);
            File.WriteAllText(fileRj, zapisiRj);
        }
    }
}
