﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Mnoyenje_u_binarnom
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();

            string nadji_nepoznat_broj(int baza, int broj)
            {
                string rjesenje_broj = "";
                int racun = 0;
                string znamenke = "0123456789ABCDEF";

                while (broj > 0)
                {
                    racun = broj % baza;
                    rjesenje_broj = znamenke[racun] + rjesenje_broj;
                    broj /= baza;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }

            int prviBroj, drugiBroj;
            int bazaGlavna = 2;

            int brojRijesenja;

            string fileZad = "zadatci.txt", fileRj = "rjesenja.txt";
            string zapisiZad = "", zapisiRj = "";

            Console.Write("Koliko zadataka tražite? ");
            int brojZadataka = Convert.ToInt32(Console.ReadLine());

            int brojIzvrsenih = 0;

            while (brojIzvrsenih < brojZadataka)
            {
            pocetak:
                prviBroj = rnd.Next(1, 257);
                drugiBroj = rnd.Next(1, 33);

                if (prviBroj < drugiBroj)
                {
                    if (drugiBroj % prviBroj == 0)
                    {
                        brojIzvrsenih++;
                        brojRijesenja = drugiBroj / prviBroj;
                        zapisiZad = zapisiZad + $"{nadji_nepoznat_broj(bazaGlavna, drugiBroj)} (2) / {nadji_nepoznat_broj(bazaGlavna, prviBroj)} (2) = X (2)\n";
                        zapisiRj = zapisiRj + $"X (2) = {nadji_nepoznat_broj(bazaGlavna, brojRijesenja)}\n";
                    }
                    else goto pocetak;
                }
                else if (drugiBroj < prviBroj)
                {
                    if (prviBroj % drugiBroj == 0)
                    {
                        brojIzvrsenih++;
                        brojRijesenja = prviBroj / drugiBroj;
                        zapisiZad = zapisiZad + $"{nadji_nepoznat_broj(bazaGlavna, prviBroj)} (2) / {nadji_nepoznat_broj(bazaGlavna, drugiBroj)} (2) = X (2)\n";
                        zapisiRj = zapisiRj + $"X (2) = {nadji_nepoznat_broj(bazaGlavna, brojRijesenja)}\n";
                    }
                    else goto pocetak;
                }
                else if (prviBroj == drugiBroj) goto pocetak;
            }

            File.WriteAllText(fileZad, zapisiZad);
            File.WriteAllText(fileRj, zapisiRj);
        }
    }
}
