﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Transformacija_realnog_broja_u_zapis_u_IEEE754_standardu
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            string dekadskiDecimalniBrojUBazi(int baza, double broj)
            {
                string rjesenje_broj = "";
                string znamenke = "0123456789ABCDEF";

                int brojCijeli = (int)broj;
                if (broj < 0) brojCijeli = Convert.ToInt32(Math.Abs(broj));

                int racunCijeliBroj = 0;
                string rjesenjeCijeliBroj = "";

                double brojDecimalni = 0;
                if (broj < 0) { brojDecimalni = broj + brojCijeli; brojDecimalni = Math.Abs(brojDecimalni); }
                if (broj > 0) brojDecimalni = broj - brojCijeli;

                int racunDecimalniBroj = 0;
                string rjesenjeDecimalniBroj = "";
                if (brojDecimalni != 0.0) rjesenjeDecimalniBroj = ".";

                while (brojCijeli != 0)
                {
                    racunCijeliBroj = brojCijeli % baza;
                    rjesenjeCijeliBroj = znamenke[racunCijeliBroj] + rjesenjeCijeliBroj;
                    brojCijeli /= baza;
                }

                int maxZnamenki = 10;
                while (brojDecimalni != 0.0 && maxZnamenki > 0)
                {
                    if (rjesenjeDecimalniBroj == "")
                        rjesenjeDecimalniBroj = ".";

                    brojDecimalni = brojDecimalni * baza;
                    racunDecimalniBroj = (int)brojDecimalni;
                    rjesenjeDecimalniBroj = rjesenjeDecimalniBroj  + znamenke[racunDecimalniBroj];
                    brojDecimalni = brojDecimalni - racunDecimalniBroj;

                    maxZnamenki--;
                }

                rjesenje_broj = rjesenjeCijeliBroj + rjesenjeDecimalniBroj;

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }

            long BrojBazeUDekadski (int bazaBroja, string broj)
            {
                long rjesenjeBroj = 0;
                int brojac = broj.Length - 1;
                int vrijednost = 0;

                for (int i = 0; i < broj.Length; i++)
                {
                    vrijednost = Convert.ToInt32(broj[brojac]);
                    rjesenjeBroj = rjesenjeBroj + (vrijednost * Convert.ToInt32(Math.Pow(bazaBroja, i)));
                    brojac--;
                }

                return rjesenjeBroj;
            }

            string BinarniUHeksadekadski( string broj )
            {
                string rezultat = "";
                char[] pomocniString = new char[4];
                string znamenke = "0123456789ABCDEF";
                int racun = 0, vrijednost = 0, potencija = 0;

                for (int i = 0; i < broj.Length - 3; i = i + 4)
                {
                    potencija = 0;

                    pomocniString[0] = broj[i];
                    pomocniString[1] = broj[i + 1];
                    pomocniString[2] = broj[i + 2];
                    pomocniString[3] = broj[i + 3];

                    for (int k = 3; k > -1; k--)
                    {
                        if (pomocniString[k] == '0') vrijednost = 0;
                        if (pomocniString[k] == '1') vrijednost = 1;
                        racun = racun + (vrijednost * Convert.ToInt32(Math.Pow(2, potencija)));
                        potencija++;
                    }

                    rezultat = rezultat + znamenke[racun];
                    racun = 0;
                }

                return rezultat;
            }

            int bazaBinarno = 2;
            double[] fractionalParts = { 0.125, 0.250, 0.375, 0.500, 0.625, 0.750, 0.875 };

            int glavniBroj, eksponent, karakteristika, nasumicniDecimalni;
            double glavniBrojPotpuni;
            string predznak = "0", finalniZapis = "", brojBinarno, finalniZapisHeksa = "", karakteristikaString;
            string[] podjeljeniDioBroja = { "0", "0" };

            string fileZad = "zadatci.txt", fileRj = "rjesenja.txt";
            string zapisiZad = "", zapisiRj = "";

            Console.Write("Koliko zadataka tražite? ");
            int brojZadataka = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i <  brojZadataka; i++)
            {
            pocetak:
                glavniBroj = random.Next(-256, 256);
                nasumicniDecimalni = random.Next(0, 7);

                glavniBrojPotpuni = glavniBroj + fractionalParts[nasumicniDecimalni];

                if (glavniBrojPotpuni < 0) predznak = "1";
                if (glavniBrojPotpuni == 0) goto pocetak;

                brojBinarno = dekadskiDecimalniBrojUBazi(bazaBinarno, glavniBrojPotpuni);

                podjeljeniDioBroja = brojBinarno.Split('.');

                eksponent = podjeljeniDioBroja[0].Length - 1;
                karakteristika = eksponent + 127;

                karakteristikaString = dekadskiDecimalniBrojUBazi(bazaBinarno, karakteristika);

                finalniZapis = $"{predznak}{karakteristikaString}{podjeljeniDioBroja[0]}";
                if (podjeljeniDioBroja[1] != "0") finalniZapis = finalniZapis + $"{podjeljeniDioBroja[1]}";

                while (finalniZapis.Length < 32) finalniZapis = finalniZapis + "0";

                finalniZapisHeksa = BinarniUHeksadekadski(finalniZapis);

                zapisiZad = zapisiZad + $"{glavniBrojPotpuni}\n";
                zapisiRj = zapisiRj + $"{finalniZapisHeksa}\n";
            }

            File.WriteAllText(fileZad, zapisiZad);
            File.WriteAllText(fileRj, zapisiRj);
        }
    }
}
