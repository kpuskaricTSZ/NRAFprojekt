﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace pisanje_u_dokument_rijesenja_i_zadatke
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nadji_nepoznat_broj (int baza2, int broj)
            {
                string rjesenje_broj = "";

                while (broj > 0)
                {
                    rjesenje_broj = (broj % baza2).ToString() + rjesenje_broj;
                    broj /= baza2;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }

            Random random = new Random();

            string broj_baza_druga = "";
            string broj_deset = "";
            int baza_1;
            int baza_2;
            string zadatci = "";
            string rjesenja = "";
            int broj_za_zadatak;

            string zadatci_filepath = "zadatci.txt";
            string rjesenja_filepath = "rjesenja.txt";

            Console.Write("Koliko zelite zadataka:  ");
            int broj_zadataka = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < broj_zadataka; i++)
            {
                broj_za_zadatak = random.Next(50, 999);
                baza_1 = random.Next(2, 10);
                baza_2 = random.Next(2, 10);

                if (baza_1 == baza_2) i--;

                broj_deset = nadji_nepoznat_broj(baza_1, broj_za_zadatak);
                broj_baza_druga = nadji_nepoznat_broj(baza_2, broj_za_zadatak);

                zadatci = zadatci + broj_deset + $" ({baza_1}) = X ({baza_2})\n";
                rjesenja = rjesenja + $"X = {broj_baza_druga}\n";
            }

            File.WriteAllText(zadatci_filepath, zadatci);
            File.WriteAllText(rjesenja_filepath, rjesenja);
        }
    }
}
