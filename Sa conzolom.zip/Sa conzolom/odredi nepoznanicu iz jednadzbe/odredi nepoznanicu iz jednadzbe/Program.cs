﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace odredi_nepoznanicu_iz_jednadzbe
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nadji_nepoznat_broj(int baza2, int broj)
            {
                string rjesenje_broj = "";

                while (broj > 0)
                {
                    rjesenje_broj = (broj % baza2).ToString() + rjesenje_broj;
                    broj /= baza2;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }

            Random random = new Random();

            int broj1, broj2, broj3;

            int baza1, nepoznataBaza, baza3;

            string zadatci = "", rjesenja = "";

            string zadatci_filepath = "zadatci.txt";
            string rjesenja_filepath = "rjesenja.txt";

            Console.Write("Koliko zelite zadataka:  ");
            int broj_zadataka = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < broj_zadataka;)
            {
                broj1 = random.Next(10, 500);
                broj2 = random.Next(10, 500);
                broj3 = broj1 + broj2;

                baza1 = random.Next(2, 10);
                nepoznataBaza = random.Next(2, 10);
                baza3 = random.Next(2, 10);
                
                if (baza1 == baza3 && baza1 == nepoznataBaza && nepoznataBaza == baza3) continue;

                string brojUzNepoznatom = nadji_nepoznat_broj(nepoznataBaza, broj2);

                if (brojUzNepoznatom.Length > 1 && brojUzNepoznatom.Length < 4)
                {
                    zadatci = zadatci + $"{nadji_nepoznat_broj(baza1, broj1)} ({baza1}) + {brojUzNepoznatom} (X) = {nadji_nepoznat_broj(baza3, broj3)} ({baza3})\n";
                    rjesenja = rjesenja + $"X = {nepoznataBaza}\n";
                    i++;
                }
            }

            File.WriteAllText(zadatci_filepath, zadatci);
            File.WriteAllText(rjesenja_filepath, rjesenja);
        }
    }
}
