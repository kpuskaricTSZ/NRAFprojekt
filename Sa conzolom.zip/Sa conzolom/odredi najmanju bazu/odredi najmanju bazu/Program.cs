﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace odredi_nepoznate_baze_iz_jednakosti
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nadji_nepoznat_broj(int baza2, int broj)
            {
                string rjesenje_broj = "";

                while (broj > 0)
                {
                    rjesenje_broj = (broj % baza2).ToString() + rjesenje_broj;
                    broj /= baza2;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }

            Random random = new Random();

            string zadatci = "", rjesenja = "";

            int glavniBroj;
            int bazaPrva, bazaDruga;

            string prviPretvorenBroj, drugiPretvorenBroj;

            string zadatci_filepath = "zadatci.txt";
            string rjesenja_filepath = "rjesenja.txt";

            Console.Write("Koliko zelite zadataka:  ");
            int broj_zadataka = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < broj_zadataka; i++)
            {
            pocetak:

                glavniBroj = random.Next(16, 257);
                bazaPrva = random.Next(2, 10);
                bazaDruga = random.Next(2, 10);

                if (bazaPrva == bazaDruga) goto pocetak;

                prviPretvorenBroj = nadji_nepoznat_broj(bazaPrva, glavniBroj);
                drugiPretvorenBroj = nadji_nepoznat_broj(bazaDruga, glavniBroj);

                if (prviPretvorenBroj[0] - '0' == bazaPrva - 1)
                {
                    zadatci = zadatci + $"{prviPretvorenBroj}(X) = {drugiPretvorenBroj}(Y)\n";
                    rjesenja = rjesenja + $"X = {bazaPrva},   Y = {bazaDruga}\n";
                }
                else goto pocetak;
            }

            File.WriteAllText(zadatci_filepath, zadatci);
            File.WriteAllText(rjesenja_filepath, rjesenja);
        }
    }
}
