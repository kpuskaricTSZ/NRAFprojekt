﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Oduzimanje_brojeva_2__8__10__16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nadji_nepoznat_broj(int baza, int broj)
            {
                string rjesenje_broj = "";
                int racun = 0;
                string znamenke = "0123456789ABCDEF";

                while (broj > 0)
                {
                    racun = broj % baza;
                    rjesenje_broj = znamenke[racun] + rjesenje_broj;
                    broj /= baza;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }

            Random rnd = new Random();

            int prviBroj, drugiBroj;

            int brojRijesenja;

            string prviBrojString, drugiBrojString, rijesenjeString;

            string fileZad = "zadatci.txt", fileRj = "rjesenja.txt";
            string zapisiZad = "", zapisiRj = "";

            Console.Write("Koliko zadataka tražite? ");
            int brojZadataka = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < brojZadataka; i++)
            {
            pocetak:
                prviBroj = rnd.Next(16, 65);
                drugiBroj = rnd.Next(16, 65);

                if (prviBroj > drugiBroj)
                {
                    brojRijesenja = prviBroj - drugiBroj;

                    prviBrojString = nadji_nepoznat_broj(2, prviBroj);
                    drugiBrojString = nadji_nepoznat_broj(2, drugiBroj);
                    rijesenjeString = nadji_nepoznat_broj(2, brojRijesenja);

                    while (drugiBrojString.Length < 7) drugiBrojString = "0" + drugiBrojString;
                    while (prviBrojString.Length < 8) prviBrojString = "0" + prviBrojString;
                    while (rijesenjeString.Length < 8) rijesenjeString = "0" + rijesenjeString;

                    drugiBrojString = "1" + drugiBrojString;

                    zapisiZad += $"{prviBrojString} + {drugiBrojString} = \n";
                }
                else
                {
                    goto pocetak;
                }

                zapisiRj += $"{rijesenjeString}\n";
            }

            File.WriteAllText(fileZad, zapisiZad);
            File.WriteAllText(fileRj, zapisiRj);
        }
    }
}
