﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Zbrajanje_brojeva_2_8_10_16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            string nadji_nepoznat_broj(int baza, int broj)
            {
                string rjesenje_broj = "";
                int racun = 0;
                string znamenke = "0123456789ABCDEF";

                while (broj > 0)
                {
                    racun = broj % baza;
                    rjesenje_broj = znamenke[racun] + rjesenje_broj;
                    broj /= baza;
                }

                if (rjesenje_broj == "")
                    return "0";
                return rjesenje_broj;
            }
            int odrediBazu(int baza)
            {
                Random random = new Random();

                int rendomBroj = random.Next(0, 5);

                if (rendomBroj == 0) baza = 2;
                if (rendomBroj == 1) baza = 4;
                if (rendomBroj == 2) baza = 8;
                if (rendomBroj == 3) baza = 10;
                if (rendomBroj == 4) baza = 16;

                return baza;
            }

            int prviBroj, drugiBroj;
            int baza1 = 0, baza2 = 0, baza3 = 0;

            int brojRijesenja;

            string fileZad = "zadatci.txt", fileRj = "rjesenja.txt";
            string zapisiZad = "", zapisiRj = "";

            Console.Write("Koliko zadataka tražite? ");
            int brojZadataka = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < brojZadataka;)
            {
                prviBroj = rnd.Next(10, 1000);
                drugiBroj = rnd.Next(10, 1000);
                brojRijesenja = prviBroj + drugiBroj;

                baza1 = odrediBazu(baza1);
                baza2 = odrediBazu(baza2);
                baza3 = odrediBazu(baza3);

                if (baza1 != baza2)
                {
                    zapisiZad += $"{nadji_nepoznat_broj(baza1, prviBroj)} ({baza1}) + {nadji_nepoznat_broj(baza2, drugiBroj)} ({baza2}) = X ({baza3})\n";
                    zapisiRj += $"X = {nadji_nepoznat_broj(baza3, brojRijesenja)}\n";
                    i++;
                }
            }

            File.WriteAllText(fileZad, zapisiZad);
            File.WriteAllText(fileRj, zapisiRj);
        }
    }
}
