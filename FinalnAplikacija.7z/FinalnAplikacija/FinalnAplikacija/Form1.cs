﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace FinalnAplikacija
{
    public partial class Form1 : Form
    {
        string drugiKomplement(string brojuBinarnom)
        {
            string rjesenje = "";

            int numberOfBits = 8;
            string brojZbrajanje = "1";

            while (brojuBinarnom.Length <= numberOfBits)
            {
                brojuBinarnom = "0" + brojuBinarnom;
            }
            while (brojZbrajanje.Length <= numberOfBits)
            {
                brojZbrajanje = "0" + brojZbrajanje;
            }

            for (int i = 0; i < brojuBinarnom.Length; i++)
            {
                if (brojuBinarnom[i] == Convert.ToChar("0")) rjesenje = rjesenje + "1";
                if (brojuBinarnom[i] == Convert.ToChar("1")) rjesenje = rjesenje + "0";
            }

            string rezultat = "";
            int prebacivanje = 0;

            int brojJedinicaURedku = 0;

            for (int i = rjesenje.Length - 1; i > 0; i--)
            {
                if (prebacivanje == 1) brojJedinicaURedku++;
                if (rjesenje[i] == Convert.ToChar("1")) brojJedinicaURedku++;
                if (brojZbrajanje[i] == Convert.ToChar("1")) brojJedinicaURedku++;

                if (brojJedinicaURedku == 0) { rezultat = "0" + rezultat; prebacivanje = 0; }
                if (brojJedinicaURedku == 1) { prebacivanje = 0; rezultat = "1" + rezultat; }
                if (brojJedinicaURedku == 2) { prebacivanje = 1; rezultat = "0" + rezultat; }
                if (brojJedinicaURedku == 3) { prebacivanje = 1; rezultat = "1" + rezultat; }
                brojJedinicaURedku = 0;
            }

            return rezultat;
        }
        int odredjivanjeBaze(Random slucajni)
        {
            int bazaOdredjivanja = 0;

            int random = slucajni.Next(1, 6);

            if (random == 1) bazaOdredjivanja = 2;
            if (random == 2) bazaOdredjivanja = 4;
            if (random == 3) bazaOdredjivanja = 8;
            if (random == 4) bazaOdredjivanja = 10;
            if (random == 5) bazaOdredjivanja = 16;

            return bazaOdredjivanja;
        }
        int odrediBazu(int baza)
        {
            Random random = new Random();

            int rendomBroj = random.Next(0, 5);

            if (rendomBroj == 0) baza = 2;
            if (rendomBroj == 1) baza = 4;
            if (rendomBroj == 2) baza = 8;
            if (rendomBroj == 3) baza = 10;
            if (rendomBroj == 4) baza = 16;

            return baza;
        }
        string BinarniUHeksadekadski(string broj)
        {
            string rezultat = "";
            char[] pomocniString = new char[4];
            string znamenke = "0123456789ABCDEF";
            int racun = 0, vrijednost = 0, potencija = 0;

            for (int i = 0; i < broj.Length - 3; i = i + 4)
            {
                potencija = 0;

                pomocniString[0] = broj[i];
                pomocniString[1] = broj[i + 1];
                pomocniString[2] = broj[i + 2];
                pomocniString[3] = broj[i + 3];

                for (int k = 3; k > -1; k--)
                {
                    if (pomocniString[k] == '0') vrijednost = 0;
                    if (pomocniString[k] == '1') vrijednost = 1;
                    racun = racun + (vrijednost * Convert.ToInt32(Math.Pow(2, potencija)));
                    potencija++;
                }

                rezultat = rezultat + znamenke[racun];
                racun = 0;
            }

            return rezultat;
        }
        string dekadskiDecimalniBrojUBazi(int baza, double broj)
        {
            string rjesenje_broj = "";
            string znamenke = "0123456789ABCDEF";

            int brojCijeli = (int)broj;
            if (broj < 0) brojCijeli = Convert.ToInt32(Math.Abs(broj));

            int racunCijeliBroj = 0;
            string rjesenjeCijeliBroj = "";

            double brojDecimalni = 0;
            if (broj < 0) { brojDecimalni = broj + brojCijeli; brojDecimalni = Math.Abs(brojDecimalni); }
            if (broj > 0) brojDecimalni = broj - brojCijeli;

            int racunDecimalniBroj = 0;
            string rjesenjeDecimalniBroj = "";
            if (brojDecimalni != 0.0) rjesenjeDecimalniBroj = ".";

            while (brojCijeli != 0)
            {
                racunCijeliBroj = brojCijeli % baza;
                rjesenjeCijeliBroj = znamenke[racunCijeliBroj] + rjesenjeCijeliBroj;
                brojCijeli /= baza;
            }

            int maxZnamenki = 10;
            while (brojDecimalni != 0.0 && maxZnamenki > 0)
            {
                if (rjesenjeDecimalniBroj == "")
                    rjesenjeDecimalniBroj = ".";

                brojDecimalni = brojDecimalni * baza;
                racunDecimalniBroj = (int)brojDecimalni;
                rjesenjeDecimalniBroj = rjesenjeDecimalniBroj + znamenke[racunDecimalniBroj];
                brojDecimalni = brojDecimalni - racunDecimalniBroj;

                maxZnamenki--;
            }

            rjesenje_broj = rjesenjeCijeliBroj + rjesenjeDecimalniBroj;

            if (rjesenje_broj == "")
                return "0";
            return rjesenje_broj;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private string fileZadPath = "zadaci.txt", fileRjePath = "rjesenja.txt";

        private void izvrsi_Click(object sender, EventArgs e)
        {
            Random random = new Random();

            // osnovne varijable
            string zadaciString = "", rjesenjaString = "";
            int brojPozeljnihGrupa = Convert.ToInt32(brojGrupa.Text);

            for (int grupa = 0; grupa < brojPozeljnihGrupa; grupa++)
            {
                zadaciString = zadaciString + $"grupa: {grupa + 1}\n\n";
                rjesenjaString = rjesenjaString + $"grupa: {grupa + 1}\n\n";

                //Transformacija iz dekadskog brojevnog sustava u bilo koji brojevni sustav čija je baza između 2 i 9
                zadaciString = zadaciString + "1. Transformacija iz dekadskog brojevnog sustava u bilo koji brojevni sustav čija je baza između 2 i 9\n\n";
                rjesenjaString = rjesenjaString + "1. Transformacija iz dekadskog brojevnog sustava u bilo koji brojevni sustav čija je baza između 2 i 9\n\n";

                int zadJedanBrojZadataka = Convert.ToInt32(brojZadataka1.Text);
                int zadJedanBrojJedan;
                int zadJedanBaza;

                string zadJedanBrojRjesenja;

                for (int i = 0; i < zadJedanBrojZadataka; i++)
                {
                    zadJedanBrojJedan = random.Next(10, 999);
                    zadJedanBaza = random.Next(2, 10);

                    zadJedanBrojRjesenja = dekadskiDecimalniBrojUBazi(zadJedanBaza, zadJedanBrojJedan);

                    zadaciString = zadaciString + $"{i + 1}.\t{zadJedanBrojJedan}(10) = X({zadJedanBaza})\n";
                    rjesenjaString = rjesenjaString + $"{i + 1}.\tX({zadJedanBaza}) = {zadJedanBrojRjesenja}\n";
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";

                //Transformacija iz bilo kojeg brojevnog sustava u brojevni sustav s bazom 10
                zadaciString = zadaciString + "2. Transformacija iz bilo kojeg brojevnog sustava u brojevni sustav s bazom 10\n\n";
                rjesenjaString = rjesenjaString + "2. Transformacija iz bilo kojeg brojevnog sustava u brojevni sustav s bazom 10\n\n";

                int zadDvaBrojZadataka = Convert.ToInt32(brojZadataka2.Text);
                int zadDvaBrojJedan;
                int zadDvaBaza;

                string zadDvaBrojRjesenja;

                for (int i = 0; i < zadDvaBrojZadataka; i++)
                {
                    zadDvaBrojJedan = random.Next(10, 999);
                    zadDvaBaza = random.Next(2, 10);

                    zadDvaBrojRjesenja = dekadskiDecimalniBrojUBazi(zadDvaBaza, zadDvaBrojJedan);

                    zadaciString = zadaciString + $"{i + 1}.\t{zadDvaBrojJedan}({zadDvaBaza}) = X(10)\n";
                    rjesenjaString = rjesenjaString + $"{i + 1}.\tX(10) = {zadDvaBrojJedan}\n";
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";

                //Transformacija iz jednog u drugi brojevni sustav, pri čemu su brojevni sustavi između 2 i 9
                zadaciString = zadaciString + "3. Transformacija iz jednog u drugi brojevni sustav, pri čemu su brojevni sustavi između 2 i 9\n\n";
                rjesenjaString = rjesenjaString + "3. Transformacija iz jednog u drugi brojevni sustav, pri čemu su brojevni sustavi između 2 i 9\n\n";

                int zadTriBrojZadataka = Convert.ToInt32(brojZadataka3.Text);
                int zadTriBrojJedan, zadTriBrojDva;
                int zadTriBazaJedan, zadTriBazaDva;

                string zadTriBrojJedanString, zadTriBrojDvaString;

                for (int i = 0; i < zadTriBrojZadataka; i++)
                {
                    zadTriBrojJedan = random.Next(10, 999);
                    zadTriBazaJedan = random.Next(2, 10);
                    zadTriBrojDva = random.Next(10, 999);
                    zadTriBazaDva = random.Next(2, 10);

                    zadTriBrojJedanString = dekadskiDecimalniBrojUBazi(zadTriBazaJedan, zadTriBrojJedan);
                    zadTriBrojDvaString = dekadskiDecimalniBrojUBazi(zadTriBazaDva, zadTriBrojDva);

                    zadaciString = zadaciString + $"{i + 1}.\t{zadTriBrojJedanString}({zadTriBazaJedan}) = X({zadTriBazaDva})\n";
                    rjesenjaString = rjesenjaString + $"{i + 1}.\tX({zadTriBazaDva}) = {zadTriBrojDvaString}\n";
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";

                //Određivanje nepoznate baze iz jednakosti
                zadaciString = zadaciString + "4. Određivanje nepoznate baze iz jednakosti\n\n";
                rjesenjaString = rjesenjaString + "4. Određivanje nepoznate baze iz jednakosti\n\n";

                int zadCetiriBrojZadatka = Convert.ToInt32(brojZadataka4.Text);
                int zadCetiriBrojJedan, zadCetiriBrojDva, zadCetiriBazaJedan, zadCetiriBazaDva;

                string zadCetiriBrojJedanString, zadCetiriBrojDvaString;

                for (int i = 0; i < zadCetiriBrojZadatka;)
                {
                zadCetiripocetak:
                    zadCetiriBrojJedan = random.Next(10, 257);
                    zadCetiriBrojDva = random.Next(10, 999);
                    zadCetiriBazaJedan = random.Next(2, 17);
                    zadCetiriBazaDva = random.Next(2, 17);

                    if (zadCetiriBazaJedan == zadCetiriBazaDva) goto zadCetiripocetak;

                    zadCetiriBrojJedanString = dekadskiDecimalniBrojUBazi(zadCetiriBazaJedan, zadCetiriBrojJedan);
                    zadCetiriBrojDvaString = dekadskiDecimalniBrojUBazi(zadCetiriBazaDva, zadCetiriBrojDva);

                    if (zadCetiriBrojJedanString.Length > 1 && zadCetiriBrojDvaString.Length < 4)
                    {
                        zadaciString = zadaciString + $"{i + 1}.\t{zadCetiriBrojJedanString}(X) = {zadCetiriBrojDvaString}({zadCetiriBazaDva})\n";
                        rjesenjaString = rjesenjaString + $"{i + 1}.\tX = {zadCetiriBazaDva}\n";
                        i++;
                    }
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                //Određivanje najmanjih brojevnih baza iz jednadžbe
                zadaciString = zadaciString + "5. Određivanje najmanjih brojevnih baza iz jednadžbe\n\n";
                rjesenjaString = rjesenjaString + "5. Određivanje najmanjih brojevnih baza iz jednadžbe\n\n";

                int zadPetBrojZadataka = Convert.ToInt32(brojZadataka5.Text);
                int zadPetBroj, zadPetBazaJedan, zadPetBazaDva;

                string zadPetPretvorenbrojJedan, zadPetPretvorenbrojDva;

                for (int i = 0; i < zadPetBrojZadataka; i++)
                {
                zadPetpocetak:

                    zadPetBroj = random.Next(16, 257);
                    zadPetBazaJedan = random.Next(2, 17);
                    zadPetBazaDva = random.Next(2, 17);

                    if (zadPetBazaDva == zadPetBazaJedan) goto zadPetpocetak;

                    zadPetPretvorenbrojJedan = dekadskiDecimalniBrojUBazi(zadPetBazaJedan, zadPetBroj);
                    zadPetPretvorenbrojDva = dekadskiDecimalniBrojUBazi(zadPetBazaDva, zadPetBroj);

                    if (zadPetPretvorenbrojJedan[0] - '0' == zadPetBazaJedan - 1)
                    {
                        zadaciString = zadaciString + $"{i + 1}.\t{zadPetPretvorenbrojJedan}(X) = {zadPetPretvorenbrojDva}(Y)\n";
                        rjesenjaString = rjesenjaString + $"{i + 1}.\tX = {zadPetBazaJedan},   Y = {zadPetBazaDva}\n";
                    }
                    else goto zadPetpocetak;
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                //Određivanje brojevne baze iz jednadžbe uz postojanje odnosa između te dvije baze primjer 121(Y) = 23(X)
                zadaciString = zadaciString + "6. Određivanje brojevne baze iz jednadžbe uz postojanje odnosa između te dvije baze primjer 121(Y + 2) = 23(X)\n\n";
                rjesenjaString = rjesenjaString + "6. Određivanje brojevne baze iz jednadžbe uz postojanje odnosa između te dvije baze primjer 121(Y + 2) = 23(X)\n\n";

                int zadSestBrojZadataka = Convert.ToInt32(brojZadataka6.Text);

                int zadSestBroj, zadSestBazaJedan, zadSestBazaDva;

                string zadSestBrojJedanString, zadSestBrojDvaString;

                int zadSestOdnos;
                int zadSestOdnosPredznak;

                int zadSestBrojIzvrsenih = 0;

                while (zadSestBrojIzvrsenih < zadSestBrojZadataka)
                {
                zadSestpocetak:

                    zadSestBroj = random.Next(10, 999);
                    zadSestBazaJedan = random.Next(2, 13);
                    zadSestOdnos = random.Next(1, 5);
                    zadSestOdnosPredznak = random.Next(1, 3);

                    if (zadSestOdnosPredznak == 1 && zadSestBazaJedan - zadSestOdnos > 1)
                    {
                        zadSestBazaDva = zadSestBazaJedan - zadSestOdnos;

                        //gleda je li prva znamenka prikladna za bazu, radi lakseg racunanja 
                        zadSestBrojJedanString = dekadskiDecimalniBrojUBazi(zadSestBazaJedan, zadSestBroj).ToString();
                        int firstDigitValue = "0123456789ABCDEF".IndexOf(zadSestBrojJedanString[0]);
                        if (firstDigitValue != zadSestBazaJedan - 1) { goto zadSestpocetak; }

                        zadSestBrojDvaString = dekadskiDecimalniBrojUBazi(zadSestBazaDva, zadSestBroj);

                        zadSestBrojIzvrsenih++;

                        zadaciString = zadaciString + $"{zadSestBrojIzvrsenih + 1}.\t{zadSestBrojJedanString}(X) = {zadSestBrojDvaString} (Y), Y = X - {zadSestOdnos}\n";
                        rjesenjaString = rjesenjaString + $"{zadSestBrojIzvrsenih + 1}.\tY = {zadSestBazaDva}, X = {zadSestBazaJedan}\n";
                    }
                    else if (zadSestOdnosPredznak == 2 && zadSestBazaJedan + zadSestOdnos < 17)
                    {
                        zadSestBazaDva = zadSestBazaJedan + zadSestOdnos;

                        //gleda je li prva znamenka prikladna za bazu, radi lakseg racunanja 
                        zadSestBrojJedanString = dekadskiDecimalniBrojUBazi(zadSestBazaJedan, zadSestBroj).ToString();
                        int firstDigitValue = "0123456789ABCDEF".IndexOf(zadSestBrojJedanString[0]);
                        if (firstDigitValue != zadSestBazaJedan - 1) { goto zadSestpocetak; }

                        zadSestBrojDvaString = dekadskiDecimalniBrojUBazi(zadSestBazaDva, zadSestBroj);

                        zadSestBrojIzvrsenih++;

                        zadaciString = zadaciString + $"{zadSestBrojIzvrsenih + 1}.\t{zadSestBrojJedanString} (X) = {zadSestBrojDvaString} (Y), Y = X + {zadSestOdnos}\n";
                        rjesenjaString = rjesenjaString + $"{zadSestBrojIzvrsenih + 1}.\tY = {zadSestBazaDva}, X = {zadSestBazaJedan}\n";
                    }
                    else { goto zadSestpocetak; }
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                // Direktna transformacija između brojevnih baza 2,4,8,i 16
                zadaciString = zadaciString + "7. Direktna transformacija između brojevnih baza 2,4,8,i 16\n\n";
                rjesenjaString = rjesenjaString + "7. Direktna transformacija između brojevnih baza 2,4,8,i 16\n\n";

                int zadSedamBrojZadataka = Convert.ToInt32(brojZadataka7.Text);

                int zadSedamBroj;
                int zadSedamBazaJedan = 0, zadSedamBazaDva = 0;

                string zadSedamBrojJedanString, zadSedamBrojDvaString;

                for (int i = 0; i < zadSedamBrojZadataka;)
                {
                    zadSedamBroj = random.Next(10, 1000);

                    zadSedamBazaJedan = odrediBazu(zadSedamBazaJedan);
                    zadSedamBazaDva = odrediBazu(zadSedamBazaDva);

                    zadSedamBrojJedanString = dekadskiDecimalniBrojUBazi(zadSedamBazaJedan, zadSedamBroj);
                    zadSedamBrojDvaString = dekadskiDecimalniBrojUBazi(zadSedamBazaDva, zadSedamBroj);

                    if (zadSedamBazaJedan != zadSedamBazaDva)
                    {
                        zadaciString += $"{i + 1}.\t{zadSedamBrojJedanString}({zadSedamBazaJedan}) = X({zadSedamBazaDva})\n";
                        rjesenjaString += $"{i + 1}.\tX = {zadSedamBrojDvaString}\n";
                        i++;
                    }
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                // Zbrajanje brojeva u brojevnim bazama 2,4,8 i 16
                zadaciString = zadaciString + "8. Zbrajanje brojeva u brojevnim bazama 2,4,8 i 1\n\n";
                rjesenjaString = rjesenjaString + "8. Zbrajanje brojeva u brojevnim bazama 2,4,8 i 1\n\n";

                int zadOsamBrojZadataka = Convert.ToInt32(brojZadataka8.Text);

                int zadOsamBrojJedan, zadOsamBrojDva, zadOsamBrojRezultat;
                int zadOsamBazaJedan = 0, zadOsamBazaDva = 0, zadOsamBazaTri = 0;

                string zadOsamBrojJedanString, zadOsamBrojDvaString, zadOsamBrojRezultatString;

                for (int i = 0; i < zadOsamBrojZadataka;)
                {
                    zadOsamBrojJedan = random.Next(10, 1000);
                    zadOsamBrojDva = random.Next(10, 1000);
                    zadOsamBrojRezultat = zadOsamBrojJedan + zadOsamBrojDva;

                    zadOsamBazaJedan = odrediBazu(zadOsamBazaJedan);
                    zadOsamBazaDva = odrediBazu(zadOsamBazaDva);
                    zadOsamBazaTri = odrediBazu(zadOsamBazaTri);

                    zadOsamBrojJedanString = dekadskiDecimalniBrojUBazi(zadOsamBazaJedan, zadOsamBrojJedan);
                    zadOsamBrojDvaString = dekadskiDecimalniBrojUBazi(zadOsamBazaDva, zadOsamBrojDva);
                    zadOsamBrojRezultatString = dekadskiDecimalniBrojUBazi(zadOsamBazaTri, zadOsamBrojRezultat);

                    if (zadOsamBazaJedan != zadOsamBazaDva)
                    {
                        zadaciString += $"{i + 1}.\t{zadOsamBrojJedanString}({zadOsamBazaJedan}) + {zadOsamBrojDvaString}({zadOsamBazaDva}) = X({zadOsamBazaTri})\n";
                        rjesenjaString += $"{i + 1}.\tX = {zadOsamBrojRezultat}\n";
                        i++;
                    }
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                // Oduzimanje brojeva u brojevnim bazama 2,4,8 i 16
                zadaciString = zadaciString + "9. Oduzimanje brojeva u brojevnim bazama 2,4,8 i 16\n\n";
                rjesenjaString = rjesenjaString + "9. Oduzimanje brojeva u brojevnim bazama 2,4,8 i 16\n\n";

                int zadDevetBrojZadataka = Convert.ToInt32(brojZadataka9.Text);

                int zadDevetBrojJedan, zadDevetBrojDva, zadDevetBrojRezultat;
                int zadDevetBazaJedan = 0, zadDevetBazaDva = 0, zadDevetBazaTri = 0;

                string zadDevetBrojJedanString, zadDevetBrojDvaString, zadDevetBrojRezultatString;

                for (int i = 0; i < zadDevetBrojZadataka;)
                {
                zadDevetpocetak:
                    zadDevetBrojJedan = random.Next(10, 1000);
                    zadDevetBrojDva = random.Next(10, 1000);

                    zadDevetBazaJedan = odrediBazu(zadDevetBazaJedan);
                    zadDevetBazaDva = odrediBazu(zadDevetBazaDva);

                    zadDevetBrojJedanString = dekadskiDecimalniBrojUBazi(zadDevetBazaJedan, zadDevetBrojJedan);
                    zadDevetBrojDvaString = dekadskiDecimalniBrojUBazi(zadDevetBazaDva, zadDevetBrojDva);

                    if (zadDevetBazaJedan != zadDevetBazaDva)
                    {
                        zadDevetBazaTri = odrediBazu(zadDevetBazaTri);

                        if (zadDevetBrojJedan < zadDevetBrojDva)
                        {
                            zadDevetBrojRezultat = zadDevetBrojDva - zadDevetBrojJedan;
                            zadaciString += $"{i + 1}.\t{zadDevetBrojDvaString}({zadDevetBazaDva}) - {zadDevetBrojJedanString}({zadDevetBazaJedan}) = X({zadDevetBazaTri})\n";
                        }
                        if (zadDevetBrojJedan > zadDevetBrojDva)
                        {
                            zadDevetBrojRezultat = zadDevetBrojJedan - zadDevetBrojDva;
                            zadaciString += $"{i + 1}.\t{zadDevetBrojJedanString}({zadDevetBazaJedan}) - {zadDevetBrojDvaString}({zadDevetBazaDva}) = X({zadDevetBazaTri})\n";
                        }
                        else goto zadDevetpocetak;

                        zadDevetBrojRezultatString = dekadskiDecimalniBrojUBazi(zadDevetBazaTri, zadDevetBrojRezultat);
                        rjesenjaString += $"{i + 1}.\tX = {zadDevetBrojRezultat}\n";
                        i++;
                    }
                    else goto zadDevetpocetak;
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                // Množenje brojeva u binarnom brojevnom sustavu
                zadaciString = zadaciString + "10. Množenje brojeva u binarnom brojevnom sustavu\n\n";
                rjesenjaString = rjesenjaString + "10. Množenje brojeva u binarnom brojevnom sustavu\n\n";

                int zadDesetBrojZadataka = Convert.ToInt32(brojZadataka10.Text);

                int zadDesetBrojJedan, zadDesetBrojDva, zadDesetBrojRijesenja;
                int zadDesetBazaGlavna = 2;

                string zadDesetBrojJedanString, zadDesetBrojDvaString, zadDesetBrojRijesenjaString;

                for (int i = 0; i < zadDesetBrojZadataka; i++)
                {
                    zadDesetBrojJedan = random.Next(1, 21);
                    zadDesetBrojDva = random.Next(1, 16);

                    zadDesetBrojRijesenja = zadDesetBrojJedan * zadDesetBrojDva;

                    zadDesetBrojJedanString = dekadskiDecimalniBrojUBazi(zadDesetBazaGlavna, zadDesetBrojJedan);
                    zadDesetBrojDvaString = dekadskiDecimalniBrojUBazi(zadDesetBazaGlavna, zadDesetBrojDva);
                    zadDesetBrojRijesenjaString = dekadskiDecimalniBrojUBazi(zadDesetBazaGlavna, zadDesetBrojRijesenja);

                    zadaciString = zadaciString + $"{i + 1}.\t{zadDesetBrojJedanString} (2) * {zadDesetBrojDvaString} (2) = X (2)\n";
                    rjesenjaString = rjesenjaString + $"{i + 1}.\tX (2) = {zadDesetBrojRijesenjaString}\n";
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                // Dijeljenje brojeva u binarnom brojevnom sustavu
                zadaciString = zadaciString + "11. Dijeljenje brojeva u binarnom brojevnom sustavu\n\n";
                rjesenjaString = rjesenjaString + "11. Dijeljenje brojeva u binarnom brojevnom sustavu\n\n";

                int zadJedanaestPrviBroj, zadJedanaestDrugiBroj, zadJedanaestBrojRijesenja;
                int zadJedanaestBazaGlavna = 2;

                string zadJedanaestBrojJedanString, zadJedanaestBrojDvaString, zadJedanaestBrojRijesenjaString;

                int zadJedanaestBrojZadataka = Convert.ToInt32(brojZadataka11.Text);

                int zadJedanaestBrojIzvrsenih = 0;

                while (zadJedanaestBrojIzvrsenih < zadJedanaestBrojZadataka)
                {
                zadJedanaestpocetak:
                    zadJedanaestPrviBroj = random.Next(1, 257);
                    zadJedanaestDrugiBroj = random.Next(1, 33);

                    if (zadJedanaestPrviBroj < zadJedanaestDrugiBroj)
                    {
                        if (zadJedanaestDrugiBroj % zadJedanaestPrviBroj == 0)
                        {
                            zadJedanaestBrojIzvrsenih++;
                            zadJedanaestBrojRijesenja = zadJedanaestDrugiBroj / zadJedanaestPrviBroj;

                            zadJedanaestBrojJedanString = dekadskiDecimalniBrojUBazi(zadJedanaestBazaGlavna, zadJedanaestPrviBroj);
                            zadJedanaestBrojDvaString = dekadskiDecimalniBrojUBazi(zadJedanaestBazaGlavna, zadJedanaestDrugiBroj);
                            zadJedanaestBrojRijesenjaString = dekadskiDecimalniBrojUBazi(zadJedanaestBazaGlavna, zadJedanaestBrojRijesenja);

                            zadaciString = zadaciString + $"{zadJedanaestBrojIzvrsenih + 1}.\t{zadJedanaestBrojDvaString}(2) / {zadJedanaestBrojJedanString}(2) = X(2)\n";
                            rjesenjaString = rjesenjaString + $"{zadJedanaestBrojIzvrsenih + 1}.\tX(2) = {zadJedanaestBrojRijesenjaString}\n";
                        }
                        else goto zadJedanaestpocetak;
                    }
                    else if (zadJedanaestDrugiBroj < zadJedanaestPrviBroj)
                    {
                        if (zadJedanaestPrviBroj % zadJedanaestDrugiBroj == 0)
                        {
                            zadJedanaestBrojIzvrsenih++;
                            zadJedanaestBrojRijesenja = zadJedanaestPrviBroj / zadJedanaestDrugiBroj;

                            zadJedanaestBrojJedanString = dekadskiDecimalniBrojUBazi(zadJedanaestBazaGlavna, zadJedanaestPrviBroj);
                            zadJedanaestBrojDvaString = dekadskiDecimalniBrojUBazi(zadJedanaestBazaGlavna, zadJedanaestDrugiBroj);
                            zadJedanaestBrojRijesenjaString = dekadskiDecimalniBrojUBazi(zadJedanaestBazaGlavna, zadJedanaestBrojRijesenja);

                            zadaciString = zadaciString + $"{zadJedanaestBrojIzvrsenih + 1}.\t{zadJedanaestBrojJedanString}(2) / {zadJedanaestBrojDvaString}(2) = X(2)\n";
                            rjesenjaString = rjesenjaString + $"{zadJedanaestBrojIzvrsenih + 1}.\tX(2) = {zadJedanaestBrojRijesenjaString}\n";
                        }
                        else goto zadJedanaestpocetak;
                    }
                    else if (zadJedanaestPrviBroj == zadJedanaestDrugiBroj) goto zadJedanaestpocetak;
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                // Rješavanje sustava linearnih jednadžbi s brojevima u brojevnim sustavima 2,4,8 i 16
                zadaciString = zadaciString + "12. Rješavanje sustava linearnih jednadžbi s brojevima u brojevnim sustavima 2,4,8 i 16\n\n";
                rjesenjaString = rjesenjaString + "12. Rješavanje sustava linearnih jednadžbi s brojevima u brojevnim sustavima 2,4,8 i 16\n\n";

                int zadDvanaestBrojJedan, zadDvanaestBrojDva, zadDvanaestBrojTri, zadDvanaestBrojCetiri, zadDvanaestBrojPet, zadDvanaestBrojSest;
                string zadDvanaestBrojJedanString, zadDvanaestBrojDvaString, zadDvanaestBrojTriString, zadDvanaestBrojCetiriString,
                    zadDvanaestBrojPetString, zadDvanaestBrojSestString;

                int zadDvanaestBazaJedan, zadDvanaestBazaDva, zadDvanaestBazaTri, zadDvanaestBazaCetiri, zadDvanaestBazaPet, zadDvanaestBazaSest;
                int zadDvanaestBazaRijesenjaJedan, zadDvanaestBazaRijesenjaDva;

                int zadDvanaestBrojRijesenjaJedan, zadDvanaestBrojRijesenjaDva;
                string zadDvanaestBrojRijesenjaJedanString, zadDvanaestBrojRijesenjaDvaString;

                int zadDvanaestBrojZadataka = Convert.ToInt32(brojZadataka12.Text);

                for (int i = 0; i < zadDvanaestBrojZadataka; i++)
                {
                    //odredjivanje brojeva
                    zadDvanaestBrojJedan = random.Next(1, 33);
                    zadDvanaestBrojDva = random.Next(1, 33);
                    zadDvanaestBrojTri = random.Next(1, 33);
                    zadDvanaestBrojCetiri = random.Next(1, 33);
                    zadDvanaestBrojPet = random.Next(1, 33);
                    zadDvanaestBrojSest = random.Next(1, 33);

                    //odredjivanje brojeva rijesenja
                    //drugiBroj i cetvrtiBroj su nepoznanice
                    zadDvanaestBrojRijesenjaJedan = zadDvanaestBrojJedan * zadDvanaestBrojDva + zadDvanaestBrojTri * zadDvanaestBrojCetiri;
                    zadDvanaestBrojRijesenjaDva = zadDvanaestBrojPet * zadDvanaestBrojDva + zadDvanaestBrojSest * zadDvanaestBrojCetiri;

                    //odredjivanje baza
                    zadDvanaestBazaJedan = odredjivanjeBaze(random);
                    zadDvanaestBazaDva = odredjivanjeBaze(random);
                    zadDvanaestBazaTri = odredjivanjeBaze(random);
                    zadDvanaestBazaCetiri = odredjivanjeBaze(random);
                    zadDvanaestBazaPet = odredjivanjeBaze(random);
                    zadDvanaestBazaSest = odredjivanjeBaze(random);

                    zadDvanaestBazaRijesenjaJedan = odredjivanjeBaze(random);
                    zadDvanaestBazaRijesenjaDva = odredjivanjeBaze(random);

                    //pretvaranje brojeva u bazu
                    zadDvanaestBrojJedanString = dekadskiDecimalniBrojUBazi(zadDvanaestBazaJedan, zadDvanaestBrojJedan);
                    zadDvanaestBrojDvaString = dekadskiDecimalniBrojUBazi(zadDvanaestBazaDva, zadDvanaestBrojDva);
                    zadDvanaestBrojTriString = dekadskiDecimalniBrojUBazi(zadDvanaestBazaTri, zadDvanaestBrojTri);
                    zadDvanaestBrojCetiriString = dekadskiDecimalniBrojUBazi(zadDvanaestBazaCetiri, zadDvanaestBrojCetiri);
                    zadDvanaestBrojPetString = dekadskiDecimalniBrojUBazi(zadDvanaestBazaPet, zadDvanaestBrojPet);
                    zadDvanaestBrojSestString = dekadskiDecimalniBrojUBazi(zadDvanaestBazaSest, zadDvanaestBrojSest);

                    zadDvanaestBrojRijesenjaJedanString = dekadskiDecimalniBrojUBazi(zadDvanaestBazaRijesenjaJedan, zadDvanaestBrojRijesenjaJedan);
                    zadDvanaestBrojRijesenjaDvaString = dekadskiDecimalniBrojUBazi(zadDvanaestBazaRijesenjaDva, zadDvanaestBrojRijesenjaDva);

                    //zapisivanje u zadatke i rijesenja
                    zadaciString = zadaciString + $"{i + 1}.\t{zadDvanaestBrojJedanString}({zadDvanaestBazaJedan}) * X({zadDvanaestBazaDva}) + " +
                    $"{zadDvanaestBrojTriString}({zadDvanaestBazaTri}) * Y({zadDvanaestBazaCetiri})" +
                    $" = {zadDvanaestBrojRijesenjaJedanString}({zadDvanaestBazaRijesenjaJedan})\n";
                    zadaciString = zadaciString + $"{i + 1}.\t{zadDvanaestBrojPetString}({zadDvanaestBazaPet}) * X({zadDvanaestBazaDva}) + " +
                    $"{zadDvanaestBrojSestString}({zadDvanaestBazaSest}) * Y({zadDvanaestBazaCetiri})" +
                    $" = {zadDvanaestBrojRijesenjaDvaString}({zadDvanaestBazaRijesenjaDva})\n\n";

                    rjesenjaString = rjesenjaString + $"{i + 1}.\tX = {zadDvanaestBrojDvaString}({zadDvanaestBazaDva})," +
                    $" Y = {zadDvanaestBrojCetiriString}({zadDvanaestBazaCetiri})\n";
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                // Oduzimanje prirodnih brojeva metodom predznaka i apsolutne vrijednosti u 8 bitnom registru
                zadaciString = zadaciString + "13. Oduzimanje prirodnih brojeva metodom predznaka i apsolutne vrijednosti u 8 bitnom registru\n\n";
                rjesenjaString = rjesenjaString + "13. Oduzimanje prirodnih brojeva metodom predznaka i apsolutne vrijednosti u 8 bitnom registru\n\n";

                int zadTrinaestBrojJedan, zadTrinaestBrojDva;

                int zadTrinaestBrojRijesenja;

                string zadTrinaestBrojJedanString, zadTrinaestBrojDvaString, zadTrinaestRijesenjeString;

                int zadTrinaestBrojZadataka = Convert.ToInt32(brojZadataka14.Text);

                for (int i = 0; i < zadTrinaestBrojZadataka; i++)
                {
                zadTrinaestpocetak:
                    zadTrinaestBrojJedan = random.Next(16, 65);
                    zadTrinaestBrojDva = random.Next(16, 65);

                    if (zadTrinaestBrojJedan > zadTrinaestBrojDva)
                    {
                        zadTrinaestBrojRijesenja = zadTrinaestBrojJedan - zadTrinaestBrojDva;

                        zadTrinaestBrojJedanString = dekadskiDecimalniBrojUBazi(2, zadTrinaestBrojJedan);
                        zadTrinaestBrojDvaString = dekadskiDecimalniBrojUBazi(2, zadTrinaestBrojDva);
                        zadTrinaestRijesenjeString = dekadskiDecimalniBrojUBazi(2, zadTrinaestBrojRijesenja);

                        while (zadTrinaestBrojDvaString.Length < 7) zadTrinaestBrojDvaString = "0" + zadTrinaestBrojDvaString;
                        while (zadTrinaestBrojJedanString.Length < 8) zadTrinaestBrojJedanString = "0" + zadTrinaestBrojJedanString;
                        while (zadTrinaestRijesenjeString.Length < 8) zadTrinaestRijesenjeString = "0" + zadTrinaestRijesenjeString;

                        zadTrinaestBrojDvaString = "1" + zadTrinaestBrojDvaString;

                        zadaciString += $"{i + 1}.\t{zadTrinaestBrojJedanString} + {zadTrinaestBrojDvaString} = \n";
                    }
                    else
                    {
                        goto zadTrinaestpocetak;
                    }

                    rjesenjaString += $"{i + 1}.\t{zadTrinaestRijesenjeString}\n";
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                // Određivanje drugog komplementa u 8 bitnom registru
                zadaciString = zadaciString + "14. Određivanje drugog komplementa u 8 bitnom registru\n\n";
                rjesenjaString = rjesenjaString + "14. Određivanje drugog komplementa u 8 bitnom registru\n\n";

                int zadCetrnaestBaza = 2;
                int zadCetrnaestBroj;
                string zadCetrnaestBrojBinarno, zadCetrnaestRjesenje;

                int zadCetrnaestBrojZadataka = Convert.ToInt32(brojZadataka15.Text);

                int zadCetrnaestBrojBitova = 8;

                for (int i = 0; i < zadCetrnaestBrojZadataka; i++)
                {
                    zadCetrnaestBroj = random.Next(16, 129);

                    zadCetrnaestBrojBinarno = dekadskiDecimalniBrojUBazi(zadCetrnaestBaza, zadCetrnaestBroj);

                    while (zadCetrnaestBrojBinarno.Length <= zadCetrnaestBrojBitova)
                    {
                        zadCetrnaestBrojBinarno = "0" + zadCetrnaestBrojBinarno;
                    }

                    zadCetrnaestRjesenje = drugiKomplement(zadCetrnaestBrojBinarno);

                    zadaciString = zadaciString + $"{i + 1}.\t-{zadCetrnaestBroj} =\n";
                    rjesenjaString = rjesenjaString + $"{i + 1}.\t{zadCetrnaestRjesenje}\n";
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                // Primjena operacije oduzimanja primjenom drugog komplementa u 8 bitnim registrima
                zadaciString = zadaciString + "15. Primjena operacije oduzimanja primjenom drugog komplementa u 8 bitnim registrima\n\n";
                rjesenjaString = rjesenjaString + "15. Primjena operacije oduzimanja primjenom drugog komplementa u 8 bitnim registrima\n\n";

                int zadPetnaestBazaGlavna = 2;
                int zadPetnaestBrojJedan, zadPetnaestBrojDva, zadPetnaestRazlika = 0;
                string zadPetnaestBrojJedanBinarno, zadPetnaestBrojDvaBinarno, zadPetnaestKomplementBrojaDva, zadPetnaestRazlikaBinarno, zadPetnaestRezultat;

                int zadPetnaestBrojZadataka = Convert.ToInt32(brojZadataka16.Text);

                int zadPetnaestBrojBitova = 8;
                int zadPetnaestBrojManjiOdNule = 0;

                for (int i = 0; i < zadPetnaestBrojZadataka; i++)
                {
                zadPetnaestpocetakLoopa:

                    zadPetnaestBrojJedan = random.Next(16, 129);
                    zadPetnaestBrojDva = random.Next(16, 129);

                    zadPetnaestRazlika = zadPetnaestBrojDva - zadPetnaestBrojJedan;
                    if (zadPetnaestBrojJedan == zadPetnaestBrojDva) goto zadPetnaestpocetakLoopa;
                    if (zadPetnaestRazlika < 0)
                    {
                        while (zadPetnaestBrojManjiOdNule + zadPetnaestRazlika != 0) zadPetnaestBrojManjiOdNule++;

                        zadPetnaestRazlikaBinarno = dekadskiDecimalniBrojUBazi(zadPetnaestBazaGlavna, zadPetnaestBrojManjiOdNule);
                        zadPetnaestRezultat = drugiKomplement(zadPetnaestRazlikaBinarno);
                    }
                    else
                    {
                        zadPetnaestRezultat = dekadskiDecimalniBrojUBazi(zadPetnaestBazaGlavna, zadPetnaestRazlika);
                        while (zadPetnaestRezultat.Length <= zadPetnaestBrojBitova) zadPetnaestRezultat = "0" + zadPetnaestRezultat;
                    }

                    zadPetnaestBrojJedanBinarno = dekadskiDecimalniBrojUBazi(zadPetnaestBazaGlavna, zadPetnaestBrojJedan);
                    while (zadPetnaestBrojJedanBinarno.Length <= zadPetnaestBrojBitova) zadPetnaestBrojJedanBinarno = "0" + zadPetnaestBrojJedanBinarno;

                    zadPetnaestBrojDvaBinarno = dekadskiDecimalniBrojUBazi(zadPetnaestBazaGlavna, zadPetnaestBrojDva);
                    zadPetnaestKomplementBrojaDva = drugiKomplement(zadPetnaestBrojDvaBinarno);

                    zadaciString = zadaciString + $"{i + 1}.\t{zadPetnaestBrojJedanBinarno} + {zadPetnaestKomplementBrojaDva} = \n";
                    rjesenjaString = rjesenjaString + $"{i + 1}.\t{zadPetnaestRezultat} (2)\t\t\t{zadPetnaestRazlika} (10)\n";

                    zadPetnaestBrojManjiOdNule = 0;
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                // Transformacija realnog broja u zapis u IEEE754 zapisu
                zadaciString = zadaciString + "16. Transformacija realnog broja u zapis u IEEE754 zapisu\n\n";
                rjesenjaString = rjesenjaString + "16. Transformacija realnog broja u zapis u IEEE754 zapisu\n\n";

                int zadSesnaestBaza = 2;
                double[] zadSesnaestFractionalParts = { 0.125, 0.250, 0.375, 0.500, 0.625, 0.750, 0.875 };

                int zadSesnaestBroj, zadSesnaestEkponent, zadSesnaestKarakteristika, zadSesnaestNasumicniDecimalni;
                double zadSesnaestPotpuniBroj;
                string zadSesnaestPredznak = "0", zadSesnaestFinalniZapis = "", zadSesnaestBrojBinarno, zadSesnaestFinalniZapisHeksa = "", zadSesnaestKarakteristikaString;
                string[] zadSesnaestPodjeljeniDioBroja = { "0", "0" };

                int zadSesnaestBrojZadataka = Convert.ToInt32(brojZadataka17.Text);

                for (int i = 0; i < zadSesnaestBrojZadataka; i++)
                {
                zadSesnaestpocetak:
                    zadSesnaestBroj = random.Next(-256, 256);
                    zadSesnaestNasumicniDecimalni = random.Next(0, 7);

                    zadSesnaestPotpuniBroj = zadSesnaestBroj + zadSesnaestFractionalParts[zadSesnaestNasumicniDecimalni];

                    if (zadSesnaestPotpuniBroj < 0) zadSesnaestPredznak = "1";
                    if (zadSesnaestPotpuniBroj == 0) goto zadSesnaestpocetak;

                    zadSesnaestBrojBinarno = dekadskiDecimalniBrojUBazi(zadSesnaestBaza, zadSesnaestPotpuniBroj);

                    zadSesnaestPodjeljeniDioBroja = zadSesnaestBrojBinarno.Split('.');

                    zadSesnaestEkponent = zadSesnaestPodjeljeniDioBroja[0].Length - 1;
                    zadSesnaestKarakteristika = zadSesnaestEkponent + 127;

                    zadSesnaestKarakteristikaString = dekadskiDecimalniBrojUBazi(zadSesnaestBaza, zadSesnaestKarakteristika);

                    zadSesnaestFinalniZapis = $"{zadSesnaestPredznak}{zadSesnaestKarakteristikaString}{zadSesnaestPodjeljeniDioBroja[0]}";
                    if (zadSesnaestPodjeljeniDioBroja[1] != "0") zadSesnaestFinalniZapis = zadSesnaestFinalniZapis + $"{zadSesnaestPodjeljeniDioBroja[1]}";

                    while (zadSesnaestFinalniZapis.Length < 32) zadSesnaestFinalniZapis = zadSesnaestFinalniZapis + "0";

                    zadSesnaestFinalniZapisHeksa = BinarniUHeksadekadski(zadSesnaestFinalniZapis);

                    zadaciString = zadaciString + $"{i + 1}.\t{zadSesnaestPotpuniBroj}\n";
                    rjesenjaString = rjesenjaString + $"{i + 1}.\t{zadSesnaestFinalniZapisHeksa}\n";
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                // Transformacija iz IEEE754 zapisa u realni broj
                zadaciString = zadaciString + "17. Transformacija iz IEEE754 zapisa u realni broj\n\n";
                rjesenjaString = rjesenjaString + "17. Transformacija iz IEEE754 zapisa u realni broj\n\n";

                int zadSedamnaestBaza = 2;
                double[] zadSedamnaestFractionalParts = { 0.125, 0.250, 0.375, 0.500, 0.625, 0.750, 0.875 };

                int zadSedamnaestBroj, zadSedamnaestEkponent, zadSedamnaestKarakteristika, zadSedamnaestNasumicniDecimalni;
                double zadSedamnaestPotpuniBroj;
                string zadSedamnaestPredznak = "0", zadSedamnaestFinalniZapis = "", zadSedamnaestBrojBinarno, zadSedamnaestFinalniZapisHeksa = "", zadSedamnaestKarakteristikaString;
                string[] zadSedamnaestPodjeljeniDioBroja = { "0", "0" };

                int zadSedamnaestBrojZadataka = Convert.ToInt32(brojZadataka18.Text);

                for (int i = 0; i < zadSedamnaestBrojZadataka; i++)
                {
                zadSedamnaestpocetak:
                    zadSedamnaestBroj = random.Next(-256, 256);
                    zadSedamnaestNasumicniDecimalni = random.Next(0, 7);

                    zadSedamnaestPotpuniBroj = zadSedamnaestBroj + zadSedamnaestFractionalParts[zadSedamnaestNasumicniDecimalni];

                    if (zadSedamnaestPotpuniBroj < 0) zadSedamnaestPredznak = "1";
                    if (zadSedamnaestPotpuniBroj == 0) goto zadSedamnaestpocetak;

                    zadSedamnaestBrojBinarno = dekadskiDecimalniBrojUBazi(zadSedamnaestBaza, zadSedamnaestPotpuniBroj);

                    zadSedamnaestPodjeljeniDioBroja = zadSedamnaestBrojBinarno.Split('.');

                    zadSedamnaestEkponent = zadSedamnaestPodjeljeniDioBroja[0].Length - 1;
                    zadSedamnaestKarakteristika = zadSedamnaestEkponent + 127;

                    zadSedamnaestKarakteristikaString = dekadskiDecimalniBrojUBazi(zadSedamnaestBaza, zadSedamnaestKarakteristika);

                    zadSedamnaestFinalniZapis = $"{zadSedamnaestPredznak}{zadSedamnaestKarakteristikaString}{zadSedamnaestPodjeljeniDioBroja[0]}";
                    if (zadSedamnaestPodjeljeniDioBroja[1] != "0") zadSedamnaestFinalniZapis = zadSedamnaestFinalniZapis + $"{zadSedamnaestPodjeljeniDioBroja[1]}";

                    while (zadSedamnaestFinalniZapis.Length < 32) zadSedamnaestFinalniZapis = zadSedamnaestFinalniZapis + "0";

                    zadSedamnaestFinalniZapisHeksa = BinarniUHeksadekadski(zadSedamnaestFinalniZapis);

                    zadaciString = zadaciString + $"{i + 1}.\t{zadSedamnaestFinalniZapisHeksa}\n";
                    rjesenjaString = rjesenjaString + $"{i + 1}.\t{zadSedamnaestPotpuniBroj}\n";
                }

                zadaciString = zadaciString + "\n";
                rjesenjaString = rjesenjaString + "\n";
                // Množenje realnog broja sa brojem koji je tipa 2N
                zadaciString = zadaciString + "18. Množenje realnog broja sa brojem koji je tipa 2N\n\n";
                rjesenjaString = rjesenjaString + "18. Množenje realnog broja sa brojem koji je tipa 2N\n\n";

                int zadOsamnaestBazaBinarno = 2;
                double[] zadOsamnaestFractionalParts = { 0.125, 0.250, 0.375, 0.500, 0.625, 0.750, 0.875 };

                int zadOsamnaestGlavniBroj, zadOsamnaestEksponent, zadOsamnaestKarakteristika, zadOsamnaestNasumicniDecimalni,
                    zadOsamnaestNovaKarakteristika, zadOsamnaestEksponentZaDva;
                double zadOsamnaestGlavniBrojPotpuni;
                string zadOsamnaestPredznak = "0", zadOsamnaestFinalniZapis = "", zadOsamnaestBrojBinarno, zadOsamnaestFinalniZapisHeksaPrvo = "",
                    zadOsamnaestKarakteristikaStringPrvo, zadOsamnaestFinalniZapisHeksaDrugo = "", zadOsamnaestKarakteristikaStringNovo, zadOsamnaestFinalniZapisNovo = "";
                string[] zadOsamnaestPodjeljeniDioBroja = { "0", "0" };

                int zadOsamnaestBrojZadataka = Convert.ToInt32(brojZadataka19.Text);

                for (int i = 0; i < zadOsamnaestBrojZadataka; i++)
                {
                zadOsamnaestpocetak:
                    zadOsamnaestGlavniBroj = random.Next(-256, 256);
                    zadOsamnaestNasumicniDecimalni = random.Next(0, 7);
                    zadOsamnaestEksponentZaDva = random.Next(1, 10);

                    zadOsamnaestGlavniBrojPotpuni = zadOsamnaestGlavniBroj + zadOsamnaestFractionalParts[zadOsamnaestNasumicniDecimalni];

                    if (zadOsamnaestGlavniBrojPotpuni < 0) zadOsamnaestPredznak = "1";
                    if (zadOsamnaestGlavniBrojPotpuni == 0) goto zadOsamnaestpocetak;

                    zadOsamnaestBrojBinarno = dekadskiDecimalniBrojUBazi(zadOsamnaestBazaBinarno, zadOsamnaestGlavniBrojPotpuni);

                    zadOsamnaestPodjeljeniDioBroja = zadOsamnaestBrojBinarno.Split('.');

                    zadOsamnaestEksponent = zadOsamnaestPodjeljeniDioBroja[0].Length - 1;
                    zadOsamnaestKarakteristika = zadOsamnaestEksponent + 127;
                    zadOsamnaestNovaKarakteristika = zadOsamnaestKarakteristika + Convert.ToInt32(Math.Pow(2, zadOsamnaestEksponentZaDva));

                    zadOsamnaestKarakteristikaStringPrvo = dekadskiDecimalniBrojUBazi(zadOsamnaestBazaBinarno, zadOsamnaestKarakteristika);
                    zadOsamnaestKarakteristikaStringNovo = dekadskiDecimalniBrojUBazi(zadOsamnaestBazaBinarno, zadOsamnaestNovaKarakteristika);

                    zadOsamnaestFinalniZapis = $"{zadOsamnaestPredznak}{zadOsamnaestKarakteristikaStringPrvo}{zadOsamnaestPodjeljeniDioBroja[0]}";
                    if (zadOsamnaestPodjeljeniDioBroja[1] != "0") zadOsamnaestFinalniZapis = zadOsamnaestFinalniZapis + $"{zadOsamnaestPodjeljeniDioBroja[1]}";

                    zadOsamnaestFinalniZapisNovo = $"{zadOsamnaestPredznak}{zadOsamnaestKarakteristikaStringNovo}{zadOsamnaestPodjeljeniDioBroja[0]}";
                    if (zadOsamnaestPodjeljeniDioBroja[1] != "0") zadOsamnaestFinalniZapisNovo = zadOsamnaestFinalniZapisNovo + $"{zadOsamnaestPodjeljeniDioBroja[1]}";

                    while (zadOsamnaestFinalniZapis.Length < 32) zadOsamnaestFinalniZapis = zadOsamnaestFinalniZapis + "0";
                    while (zadOsamnaestFinalniZapisNovo.Length < 32) zadOsamnaestFinalniZapisNovo = zadOsamnaestFinalniZapisNovo + "0";

                    zadOsamnaestFinalniZapisHeksaPrvo = BinarniUHeksadekadski(zadOsamnaestFinalniZapis);
                    zadOsamnaestFinalniZapisHeksaDrugo = BinarniUHeksadekadski(zadOsamnaestFinalniZapisNovo);

                    zadaciString = zadaciString + $"{i + 1}.\t{zadOsamnaestFinalniZapisHeksaPrvo} * {(int)Math.Pow(2, zadOsamnaestEksponentZaDva)} =\n";
                    rjesenjaString = rjesenjaString + $"{i + 1}.\t{zadOsamnaestFinalniZapisHeksaDrugo}\n";
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                // Dijeljenje realnog broja sa brojem koji je tipa 2N
                zadaciString = zadaciString + "19. Dijeljenje realnog broja sa brojem koji je tipa 2N\n\n";
                rjesenjaString = rjesenjaString + "19. Dijeljenje realnog broja sa brojem koji je tipa 2N\n\n";

                int zadDevetnaestBazaBinarno = 2;
                double[] zadDevetnaestFractionalParts = { 0.125, 0.250, 0.375, 0.500, 0.625, 0.750, 0.875 };

                int zadDevetnaestGlavniBroj, zadDevetnaestEksponent, zadDevetnaestKarakteristika, zadDevetnaestNasumicniDecimalni,
                    zadDevetnaestNovaKarakteristika, zadDevetnaestEksponentZaDva;
                double zadDevetnaestGlavniBrojPotpuni;
                string zadDevetnaestPredznak = "0", zadDevetnaestFinalniZapis = "", zadDevetnaestBrojBinarno, zadDevetnaestFinalniZapisHeksaPrvo = "",
                    zadDevetnaestKarakteristikaStringPrvo, zadDevetnaestFinalniZapisHeksaDrugo = "", zadDevetnaestKarakteristikaStringNovo, zadDevetnaestFinalniZapisNovo = "";
                string[] zadDevetnaestPodjeljeniDioBroja = { "0", "0" };

                int zadDevetnaestBrojZadataka = Convert.ToInt32(brojZadataka20.Text);

                for (int i = 0; i < zadDevetnaestBrojZadataka; i++)
                {
                zadDevetnaestpocetak:
                    zadDevetnaestGlavniBroj = random.Next(-256, 256);
                    zadDevetnaestNasumicniDecimalni = random.Next(0, 7);
                    zadDevetnaestEksponentZaDva = random.Next(1, 10);

                    zadDevetnaestGlavniBrojPotpuni = zadDevetnaestGlavniBroj + zadDevetnaestFractionalParts[zadDevetnaestNasumicniDecimalni];

                    if (zadDevetnaestGlavniBrojPotpuni < 0) zadDevetnaestPredznak = "1";
                    if (zadDevetnaestGlavniBrojPotpuni == 0) goto zadDevetnaestpocetak;

                    zadDevetnaestBrojBinarno = dekadskiDecimalniBrojUBazi(zadDevetnaestBazaBinarno, zadDevetnaestGlavniBrojPotpuni);

                    zadDevetnaestPodjeljeniDioBroja = zadDevetnaestBrojBinarno.Split('.');

                    zadDevetnaestEksponent = zadDevetnaestPodjeljeniDioBroja[0].Length - 1;
                    zadDevetnaestKarakteristika = zadDevetnaestEksponent + 127;
                    zadDevetnaestNovaKarakteristika = zadDevetnaestKarakteristika - Convert.ToInt32(Math.Pow(2, zadDevetnaestEksponentZaDva));

                    zadDevetnaestKarakteristikaStringPrvo = dekadskiDecimalniBrojUBazi(zadDevetnaestBazaBinarno, zadDevetnaestKarakteristika);
                    zadDevetnaestKarakteristikaStringNovo = dekadskiDecimalniBrojUBazi(zadDevetnaestBazaBinarno, zadDevetnaestNovaKarakteristika);

                    zadDevetnaestFinalniZapis = $"{zadDevetnaestPredznak}{zadDevetnaestKarakteristikaStringPrvo}{zadDevetnaestPodjeljeniDioBroja[0]}";
                    if (zadDevetnaestPodjeljeniDioBroja[1] != "0") zadDevetnaestFinalniZapis = zadDevetnaestFinalniZapis + $"{zadDevetnaestPodjeljeniDioBroja[1]}";

                    zadDevetnaestFinalniZapisNovo = $"{zadDevetnaestPredznak}{zadDevetnaestKarakteristikaStringNovo}{zadDevetnaestPodjeljeniDioBroja[0]}";
                    if (zadDevetnaestPodjeljeniDioBroja[1] != "0") zadDevetnaestFinalniZapisNovo = zadDevetnaestFinalniZapisNovo + $"{zadDevetnaestPodjeljeniDioBroja[1]}";

                    while (zadDevetnaestFinalniZapis.Length < 32) zadDevetnaestFinalniZapis = zadDevetnaestFinalniZapis + "0";
                    while (zadDevetnaestFinalniZapisNovo.Length < 32) zadDevetnaestFinalniZapisNovo = zadDevetnaestFinalniZapisNovo + "0";

                    zadDevetnaestFinalniZapisHeksaPrvo = BinarniUHeksadekadski(zadDevetnaestFinalniZapis);
                    zadDevetnaestFinalniZapisHeksaDrugo = BinarniUHeksadekadski(zadDevetnaestFinalniZapisNovo);

                    zadaciString = zadaciString + $"{i + 1}.\t{zadDevetnaestFinalniZapisHeksaPrvo} / {(int)Math.Pow(2, zadDevetnaestEksponentZaDva)} =\n";
                    rjesenjaString = rjesenjaString + $"{i + 1}.\t{zadDevetnaestFinalniZapisHeksaDrugo}\n";
                }

                zadaciString = zadaciString + "\n\n\n";
                rjesenjaString = rjesenjaString + "\n\n\n";
                
                // page break nakon završetka pisanja grupe
                zadaciString = zadaciString + "\f\n";
                rjesenjaString = rjesenjaString + "\f\n";
            }
            // zapisivanje u datoteke
            File.WriteAllText(fileZadPath, zadaciString);
            File.WriteAllText(fileRjePath, rjesenjaString);
        }

        private void buttonIzlaz_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void prikazZadataka_Click(object sender, EventArgs e)
        {
            var psi = new ProcessStartInfo(fileZadPath)
            {
                UseShellExecute = true
            };

            Process.Start(psi);
        }

        private void prikazRijesenja_Click(object sender, EventArgs e)
        {
            var psi = new ProcessStartInfo(fileRjePath)
            {
                UseShellExecute = true
            };

            Process.Start(psi);
        }
    }
}
