﻿namespace FinalnAplikacija
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            brojZadataka1 = new TextBox();
            brojZadataka6 = new TextBox();
            brojZadataka5 = new TextBox();
            brojZadataka4 = new TextBox();
            brojZadataka3 = new TextBox();
            brojZadataka2 = new TextBox();
            brojZadataka12 = new TextBox();
            brojZadataka11 = new TextBox();
            brojZadataka10 = new TextBox();
            brojZadataka9 = new TextBox();
            brojZadataka8 = new TextBox();
            brojZadataka7 = new TextBox();
            brojZadataka17 = new TextBox();
            brojZadataka16 = new TextBox();
            brojZadataka15 = new TextBox();
            brojZadataka14 = new TextBox();
            brojZadataka20 = new TextBox();
            brojZadataka19 = new TextBox();
            brojZadataka18 = new TextBox();
            izvrsi = new Button();
            prikazRijesenja = new Button();
            prikazZadataka = new Button();
            buttonIzlaz = new Button();
            groupBox1 = new GroupBox();
            brojGrupa = new TextBox();
            label13 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 68);
            label1.Name = "label1";
            label1.Size = new Size(529, 15);
            label1.TabIndex = 0;
            label1.Text = "1. Transformacija iz dekadskog brojevnog sustava u bilo koji brojevni sustav čija je baza između 2 i 9";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 98);
            label2.Name = "label2";
            label2.Size = new Size(415, 15);
            label2.TabIndex = 1;
            label2.Text = "2. Transformacija iz bilo kojeg brojevnog sustava u brojevni sustav s bazom 10";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 130);
            label3.Name = "label3";
            label3.Size = new Size(489, 15);
            label3.TabIndex = 2;
            label3.Text = "3. Transformacija iz jednog u drugi brojevni sustav, pri čemu su brojevni sustavi između 2 i 9";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 165);
            label4.Name = "label4";
            label4.Size = new Size(236, 15);
            label4.TabIndex = 3;
            label4.Text = "4. Određivanje nepoznate baze iz jednakosti";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(9, 200);
            label5.Name = "label5";
            label5.Size = new Size(287, 15);
            label5.TabIndex = 4;
            label5.Text = "5. Određivanje najmanjih brojevnih baza iz jednadžbe";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(9, 232);
            label6.Name = "label6";
            label6.Size = new Size(452, 15);
            label6.TabIndex = 5;
            label6.Text = "6. Određivanje brojevne baze iz jednadžbe uz postojanje odnosa između te dvije baze";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(9, 265);
            label7.Name = "label7";
            label7.Size = new Size(312, 15);
            label7.TabIndex = 6;
            label7.Text = "7. Direktna transformacija između brojevnih baza 2,4,8,i 16";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(12, 295);
            label8.Name = "label8";
            label8.Size = new Size(269, 15);
            label8.TabIndex = 7;
            label8.Text = "8. Zbrajanje brojeva u brojevnim bazama 2,4,8 i 16";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(12, 325);
            label9.Name = "label9";
            label9.Size = new Size(284, 15);
            label9.TabIndex = 8;
            label9.Text = "9. Oduzimanje brojeva u brojevnim bazama 2,4,8 i 16";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(12, 358);
            label10.Name = "label10";
            label10.Size = new Size(288, 15);
            label10.TabIndex = 9;
            label10.Text = "10. Množenje brojeva u binarnom brojevnom sustavu";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(12, 390);
            label11.Name = "label11";
            label11.Size = new Size(284, 15);
            label11.TabIndex = 10;
            label11.Text = "11. Dijeljenje brojeva u binarnom brojevnom sustavu";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(12, 423);
            label12.Name = "label12";
            label12.Size = new Size(460, 15);
            label12.TabIndex = 11;
            label12.Text = "12. Rješavanje sustava linearnih jednadžbi s brojevima u brojevnim sustavima 2,4,8 i 16";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(15, 454);
            label14.Name = "label14";
            label14.Size = new Size(476, 15);
            label14.TabIndex = 13;
            label14.Text = "13. Oduzimanje prirodnih brojeva metodom predznaka i apsolutne vrijednosti u 8 bitnom";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(15, 486);
            label15.Name = "label15";
            label15.Size = new Size(312, 15);
            label15.TabIndex = 14;
            label15.Text = "14. Određivanje drugog komplementa u 8 bitnom registru";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(15, 518);
            label16.Name = "label16";
            label16.Size = new Size(482, 15);
            label16.TabIndex = 15;
            label16.Text = "15. Primjena operacije oduzimanja primjenom drugog komplementa u 8 bitnim registrima";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(15, 550);
            label17.Name = "label17";
            label17.Size = new Size(302, 15);
            label17.TabIndex = 16;
            label17.Text = "16. Transformacija realnog broja u zapis u IEEE754 zapisu";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(15, 576);
            label18.Name = "label18";
            label18.Size = new Size(256, 15);
            label18.TabIndex = 17;
            label18.Text = "17. Transformacija iz IEEE754 zapisa u realni broj";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(718, 68);
            label19.Name = "label19";
            label19.Size = new Size(280, 15);
            label19.TabIndex = 18;
            label19.Text = "18. Množenje realnog broja sa brojem koji je tipa 2N";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(718, 97);
            label20.Name = "label20";
            label20.Size = new Size(276, 15);
            label20.TabIndex = 19;
            label20.Text = "19. Dijeljenje realnog broja sa brojem koji je tipa 2N";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label21.Location = new Point(417, 9);
            label21.Name = "label21";
            label21.Size = new Size(524, 30);
            label21.TabIndex = 20;
            label21.Text = "Odaberite broj zadataka, koje želite i koliko ih želite";
            // 
            // brojZadataka1
            // 
            brojZadataka1.Location = new Point(547, 65);
            brojZadataka1.Name = "brojZadataka1";
            brojZadataka1.Size = new Size(100, 23);
            brojZadataka1.TabIndex = 21;
            brojZadataka1.Text = "0";
            // 
            // brojZadataka6
            // 
            brojZadataka6.Location = new Point(467, 229);
            brojZadataka6.Name = "brojZadataka6";
            brojZadataka6.Size = new Size(100, 23);
            brojZadataka6.TabIndex = 22;
            brojZadataka6.Text = "0";
            // 
            // brojZadataka5
            // 
            brojZadataka5.Location = new Point(302, 197);
            brojZadataka5.Name = "brojZadataka5";
            brojZadataka5.Size = new Size(100, 23);
            brojZadataka5.TabIndex = 23;
            brojZadataka5.Text = "0";
            // 
            // brojZadataka4
            // 
            brojZadataka4.Location = new Point(254, 162);
            brojZadataka4.Name = "brojZadataka4";
            brojZadataka4.Size = new Size(100, 23);
            brojZadataka4.TabIndex = 24;
            brojZadataka4.Text = "0";
            // 
            // brojZadataka3
            // 
            brojZadataka3.Location = new Point(507, 127);
            brojZadataka3.Name = "brojZadataka3";
            brojZadataka3.Size = new Size(100, 23);
            brojZadataka3.TabIndex = 25;
            brojZadataka3.Text = "0";
            // 
            // brojZadataka2
            // 
            brojZadataka2.Location = new Point(433, 94);
            brojZadataka2.Name = "brojZadataka2";
            brojZadataka2.Size = new Size(100, 23);
            brojZadataka2.TabIndex = 26;
            brojZadataka2.Text = "0";
            // 
            // brojZadataka12
            // 
            brojZadataka12.Location = new Point(478, 420);
            brojZadataka12.Name = "brojZadataka12";
            brojZadataka12.Size = new Size(100, 23);
            brojZadataka12.TabIndex = 27;
            brojZadataka12.Text = "0";
            // 
            // brojZadataka11
            // 
            brojZadataka11.Location = new Point(302, 387);
            brojZadataka11.Name = "brojZadataka11";
            brojZadataka11.Size = new Size(100, 23);
            brojZadataka11.TabIndex = 28;
            brojZadataka11.Text = "0";
            // 
            // brojZadataka10
            // 
            brojZadataka10.Location = new Point(302, 355);
            brojZadataka10.Name = "brojZadataka10";
            brojZadataka10.Size = new Size(100, 23);
            brojZadataka10.TabIndex = 29;
            brojZadataka10.Text = "0";
            // 
            // brojZadataka9
            // 
            brojZadataka9.Location = new Point(302, 322);
            brojZadataka9.Name = "brojZadataka9";
            brojZadataka9.Size = new Size(100, 23);
            brojZadataka9.TabIndex = 30;
            brojZadataka9.Text = "0";
            // 
            // brojZadataka8
            // 
            brojZadataka8.Location = new Point(287, 292);
            brojZadataka8.Name = "brojZadataka8";
            brojZadataka8.Size = new Size(100, 23);
            brojZadataka8.TabIndex = 31;
            brojZadataka8.Text = "0";
            // 
            // brojZadataka7
            // 
            brojZadataka7.Location = new Point(330, 262);
            brojZadataka7.Name = "brojZadataka7";
            brojZadataka7.Size = new Size(100, 23);
            brojZadataka7.TabIndex = 32;
            brojZadataka7.Text = "0";
            // 
            // brojZadataka17
            // 
            brojZadataka17.Location = new Point(323, 547);
            brojZadataka17.Name = "brojZadataka17";
            brojZadataka17.Size = new Size(100, 23);
            brojZadataka17.TabIndex = 33;
            brojZadataka17.Text = "0";
            // 
            // brojZadataka16
            // 
            brojZadataka16.Location = new Point(507, 515);
            brojZadataka16.Name = "brojZadataka16";
            brojZadataka16.Size = new Size(100, 23);
            brojZadataka16.TabIndex = 34;
            brojZadataka16.Text = "0";
            // 
            // brojZadataka15
            // 
            brojZadataka15.Location = new Point(333, 483);
            brojZadataka15.Name = "brojZadataka15";
            brojZadataka15.Size = new Size(100, 23);
            brojZadataka15.TabIndex = 35;
            brojZadataka15.Text = "0";
            // 
            // brojZadataka14
            // 
            brojZadataka14.Location = new Point(497, 451);
            brojZadataka14.Name = "brojZadataka14";
            brojZadataka14.Size = new Size(100, 23);
            brojZadataka14.TabIndex = 36;
            brojZadataka14.Text = "0";
            // 
            // brojZadataka20
            // 
            brojZadataka20.Location = new Point(1004, 94);
            brojZadataka20.Name = "brojZadataka20";
            brojZadataka20.Size = new Size(100, 23);
            brojZadataka20.TabIndex = 38;
            brojZadataka20.Text = "0";
            // 
            // brojZadataka19
            // 
            brojZadataka19.Location = new Point(1004, 65);
            brojZadataka19.Name = "brojZadataka19";
            brojZadataka19.Size = new Size(100, 23);
            brojZadataka19.TabIndex = 39;
            brojZadataka19.Text = "0";
            // 
            // brojZadataka18
            // 
            brojZadataka18.Location = new Point(277, 573);
            brojZadataka18.Name = "brojZadataka18";
            brojZadataka18.Size = new Size(100, 23);
            brojZadataka18.TabIndex = 40;
            brojZadataka18.Text = "0";
            // 
            // izvrsi
            // 
            izvrsi.BackColor = Color.FromArgb(0, 192, 192);
            izvrsi.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            izvrsi.Location = new Point(718, 407);
            izvrsi.Name = "izvrsi";
            izvrsi.Size = new Size(154, 80);
            izvrsi.TabIndex = 41;
            izvrsi.Text = "IZVRŠI";
            izvrsi.UseVisualStyleBackColor = false;
            izvrsi.Click += izvrsi_Click;
            // 
            // prikazRijesenja
            // 
            prikazRijesenja.BackColor = Color.BurlyWood;
            prikazRijesenja.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            prikazRijesenja.Location = new Point(716, 515);
            prikazRijesenja.Name = "prikazRijesenja";
            prikazRijesenja.Size = new Size(156, 76);
            prikazRijesenja.TabIndex = 42;
            prikazRijesenja.Text = "OTVORI RIJEŠENJA";
            prikazRijesenja.UseVisualStyleBackColor = false;
            prikazRijesenja.Click += prikazRijesenja_Click;
            // 
            // prikazZadataka
            // 
            prikazZadataka.BackColor = Color.PaleGoldenrod;
            prikazZadataka.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            prikazZadataka.Location = new Point(950, 407);
            prikazZadataka.Name = "prikazZadataka";
            prikazZadataka.Size = new Size(154, 80);
            prikazZadataka.TabIndex = 43;
            prikazZadataka.Text = "OTVORI ZADATKE";
            prikazZadataka.UseVisualStyleBackColor = false;
            prikazZadataka.Click += prikazZadataka_Click;
            // 
            // buttonIzlaz
            // 
            buttonIzlaz.BackColor = Color.Thistle;
            buttonIzlaz.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonIzlaz.Location = new Point(950, 515);
            buttonIzlaz.Name = "buttonIzlaz";
            buttonIzlaz.Size = new Size(154, 76);
            buttonIzlaz.TabIndex = 44;
            buttonIzlaz.Text = "IZLAZ";
            buttonIzlaz.UseVisualStyleBackColor = false;
            buttonIzlaz.Click += buttonIzlaz_Click;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.FromArgb(192, 255, 255);
            groupBox1.Controls.Add(brojGrupa);
            groupBox1.Controls.Add(label13);
            groupBox1.Location = new Point(704, 229);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(419, 70);
            groupBox1.TabIndex = 45;
            groupBox1.TabStop = false;
            groupBox1.Text = "Broj Različitih Grupa";
            // 
            // brojGrupa
            // 
            brojGrupa.Location = new Point(287, 31);
            brojGrupa.Name = "brojGrupa";
            brojGrupa.Size = new Size(100, 23);
            brojGrupa.TabIndex = 1;
            brojGrupa.Text = "1";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label13.Location = new Point(6, 29);
            label13.Name = "label13";
            label13.Size = new Size(275, 21);
            label13.TabIndex = 0;
            label13.Text = "Unesite koliko različitih grupa želite:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PaleGreen;
            ClientSize = new Size(1291, 640);
            Controls.Add(groupBox1);
            Controls.Add(buttonIzlaz);
            Controls.Add(prikazZadataka);
            Controls.Add(prikazRijesenja);
            Controls.Add(izvrsi);
            Controls.Add(brojZadataka18);
            Controls.Add(brojZadataka19);
            Controls.Add(brojZadataka20);
            Controls.Add(brojZadataka14);
            Controls.Add(brojZadataka15);
            Controls.Add(brojZadataka16);
            Controls.Add(brojZadataka17);
            Controls.Add(brojZadataka7);
            Controls.Add(brojZadataka8);
            Controls.Add(brojZadataka9);
            Controls.Add(brojZadataka10);
            Controls.Add(brojZadataka11);
            Controls.Add(brojZadataka12);
            Controls.Add(brojZadataka2);
            Controls.Add(brojZadataka3);
            Controls.Add(brojZadataka4);
            Controls.Add(brojZadataka5);
            Controls.Add(brojZadataka6);
            Controls.Add(brojZadataka1);
            Controls.Add(label21);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private TextBox brojZadataka1;
        private TextBox brojZadataka6;
        private TextBox brojZadataka5;
        private TextBox brojZadataka4;
        private TextBox brojZadataka3;
        private TextBox brojZadataka2;
        private TextBox brojZadataka12;
        private TextBox brojZadataka11;
        private TextBox brojZadataka10;
        private TextBox brojZadataka9;
        private TextBox brojZadataka8;
        private TextBox brojZadataka7;
        private TextBox brojZadataka17;
        private TextBox brojZadataka16;
        private TextBox brojZadataka15;
        private TextBox brojZadataka14;
        private TextBox brojZadataka20;
        private TextBox brojZadataka19;
        private TextBox brojZadataka18;
        private Button izvrsi;
        private Button prikazRijesenja;
        private Button prikazZadataka;
        private Button buttonIzlaz;
        private GroupBox groupBox1;
        private TextBox brojGrupa;
        private Label label13;
    }
}
